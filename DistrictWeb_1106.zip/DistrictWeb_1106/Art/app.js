

var an_storageRef = firebase.storage().ref();

const Ann_List = document.querySelector('#art');
const addBtn = document.getElementById('addBtn');
const firstBtn = document.getElementById('firstBtn');
const form = document.querySelector('#an_form');


const div = sessionStorage.getItem("div");
console.log(div);

if (div === null || div === "4") {




    an_db.collection('announcement').orderBy("createdAt", 'desc').onSnapshot(snapshot => {
        let changes = snapshot.docChanges();
        changes.forEach(change => {
            console.log(change.doc.data());
            if (change.type == 'added') {
                renderCafe(change.doc);
            } else if (change.type == 'removed') {
                let li = Ann_List.querySelector('[data-id=' + change.doc.id + ']');
                Ann_List.removeChild(li);
            }
        });

    });
} else {
    rundiv();

}




// create element & render cafe
function renderCafe(doc) {
    let li = document.createElement('li');
    let title = document.createElement('span');
    let time = document.createElement('span');
    let createdby = document.createElement('span');
    let content = document.createElement('span');
    const img = document.createElement('img');
    let field1 = document.createElement('span');
    let field2 = document.createElement('span');
    let field3 = document.createElement('span');
    let cross = document.createElement('div');
    let up = document.createElement('div2');
    var photoUrl = doc.data().photoUrl;

    var readableDate = doc.data().createdAt.toDate().toLocaleString();
    img.src = photoUrl;

    console.log(readableDate);

    li.setAttribute('data-id', doc.id);
    title.textContent = ("Title: " + doc.data().title + "  ( " + doc.data().artLevel + " )");
    time.textContent = readableDate;
    createdby.textContent = ("createBy: " + doc.data().createdBy);
    content.textContent = ("Content : " + doc.data().content);
    cross.textContent = ' ';
    up.textContent = ' ';






    li.appendChild(title);

    li.appendChild(time);
    li.appendChild(createdby);
    li.appendChild(content);
    li.appendChild(img);
    li.appendChild(up);
    li.appendChild(cross);
    Ann_List.appendChild(li);
    up.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        location.href = "modify_announcement.html";
    })


    // deleting data
    cross.addEventListener('click', (e) => {
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('announcement').doc(id).delete();
                    swal("Poof! Your imaginary file has been deleted!", {
                        icon: "success",
                    });
                } else {
                    swal("Your imaginary file is safe!");
                }
            });

    });
}


function add() {
    location.href = "add_announcement.html";
}

function first() {
    location.href = "../index.html";
}

// getting data
// db.collection('cafes').orderBy('city').get().then(snapshot => {
//     snapshot.docs.forEach(doc => {
//         renderCafe(doc);
//     });
// });

// saving data
addBtn.addEventListener('click', (e) => {
    add();
});
firstBtn.addEventListener('click', (e) => {
    first();
});







function rundiv() {

    an_db.collection('announcement').where("artLevNum", "==", div).onSnapshot(snapshot => {
        let changes = snapshot.docChanges();
        changes.forEach(change => {
            console.log(change.doc.data());
            if (change.type == 'added') {
                renderCafe(change.doc);
            } else if (change.type == 'removed') {
                let li = Ann_List.querySelector('[data-id=' + change.doc.id + ']');
                Ann_List.removeChild(li);
            }
        });


    });
}


// updating records (console demo)
// db.collection('cafes').doc('DOgwUvtEQbjZohQNIeMr').update({
//     name: 'mario world'
// });

// db.collection('cafes').doc('DOgwUvtEQbjZohQNIeMr').update({
//     city: 'hong kong'
// });

// setting data
// db.collection('cafes').doc('DOgwUvtEQbjZohQNIeMr').set({
//     city: 'hong kong'
// });


function divf(a) {
    divNum = (a.value || a.options[a.selectedIndex].value); //crossbrowser solution =)

    if (divNum === "EM") {
        sessionStorage.setItem("div", "3");
        location.href = "announcement.html";

    } else if (divNum === "CM") {
        sessionStorage.setItem("div", "2");
        location.href = "announcement.html";
    } else if (divNum === "CS") {
        sessionStorage.setItem("div", "1");
        location.href = "announcement.html";

    } else {
        sessionStorage.setItem("div", "4");
        location.href = "announcement.html";
    }

}