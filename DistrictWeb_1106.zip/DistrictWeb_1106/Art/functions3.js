const addBtn = document.getElementById('addBtn');
const backBtn = document.getElementById('backBtn');


const usersCollection = an_db.collection('announcement');
const doc_key = sessionStorage.getItem('key');
console.log(doc_key);
var docRef = an_db.collection("announcement").doc(doc_key);
var title2;
var content2;
var artLev;
var artLevNum;


var docRef2 = an_db.collection("admin").doc(AdminId);

docRef2.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        AdminName = doc.data().name;
        console.log(AdminName);

        addBtn.addEventListener('click', e => {

            if (title.value === null || title.value === '' || content.value === null || content.value === '') {
                swal("請輸入標題內容");
            } else {
                e.preventDefault();
                const ref = firebase.storage().ref();
                const file = document.querySelector("#photo").files[0];
                const name = file.name;

                const metadata = {
                    contentType: file.type
                };
                const task = ref.child(name).put(file, metadata);
                task
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then(url => {

                        console.log(url);
                        const ID = usersCollection.doc(doc_key).update({
                            title: title.value,
                            content: content.value,
                            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                            createdBy: AdminName,
                            artLevel: artLev,
                            artLevNum: artLevNum,
                            photoUrl: url

                        }).then(() => {
                            console.log('Data has been saved successfully !')
                        })
                        swal({
                            title: "Good job!",
                            text: "You clicked the button!",
                            icon: "success",
                            button: "Send successfully!",
                        }).catch(error => {
                            console.error(error)
                        });
                        document.querySelector("#image").src = url;
                    })
                    .catch(console.error);
                console.log(artLevNum);


            }
        });

    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});


backBtn.addEventListener('click', e => {
    location.href = "announcement.html";

});


docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        title2 = doc.data().title;
        console.log(title2);
        content2 = doc.data().content;
        console.log(content2);
        var title = document.getElementById('title').value += title2;
        var content = document.getElementById('content').value += content2;
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

function test(a) {
    artLev = (a.value || a.options[a.selectedIndex].value); //crossbrowser solution =)
    if (artLev === "緊急公告") {
        artLevNum = "3";
    } else if (artLev === "議題公告") {
        artLevNum = "2";
    } else {
        artLevNum = "1";
    }

    console.log(artLevNum);
}