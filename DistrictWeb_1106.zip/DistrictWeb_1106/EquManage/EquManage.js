//
const Equlist = document.querySelector('#Equ-list');
const Equ_Ann_list = document.querySelector('#Equ-Ann-list');
var storageRef = firebase.storage().ref(); 
const key = sessionStorage.getItem('key');
console.log(key);

//公告head
function fMrenderVser(doc){
    let li = document.createElement('li');
    let 公告標題 = document.createElement('span');
    let 公告項目 = document.createElement('span');
    let 公告事由 = document.createElement('span');
    let 公告地點 = document.createElement('span');
    let 公告狀態 = document.createElement('span');
    let 公告細項 = document.createElement('span');
    let 關閉細項 = document.createElement('span');

    let li2 = document.createElement('li2');
    let 公告說明 = document.createElement('span');
    let 啟用 = document.createElement("button");
    let 結束 = document.createElement("button");


//get Unique ID
    li.setAttribute('data-id', doc.id);
    li2.setAttribute('data-id', doc.id);
    公告標題.textContent = (doc.data().標題);
    公告項目.textContent = (doc.data().項目);
    公告事由.textContent = ('公告事由 : '+ doc.data().事由);
    公告地點.textContent =(doc.data().報修地點);
    公告說明.textContent =('公告說明 : '+ doc.data().說明);
    公告狀態.textContent =(doc.data().狀態);
    公告細項.textContent ='查看細項';
    關閉細項.textContent ='關閉細項';
    啟用.textContent = '啟用';
    結束.textContent = '關閉';
    


    li.appendChild(公告標題);
    li.appendChild(公告項目);
    
    li.appendChild(公告地點);
    li.appendChild(公告狀態);
    li.appendChild(公告細項);
    li.appendChild(啟用);
    Equ_Ann_list.appendChild(li);
    Equ_Ann_list.appendChild(li2);
    Equ_Ann_list.style.display = 'none';
    


    //字體顏色

    if(doc.data().狀態 =="處理中" ){

        公告狀態.style.color = 'red';
        li.replaceChild(結束,啟用);

    }else if(doc.data().狀態 =="已完成"){

        公告狀態.style.color = 'black';
        li.replaceChild(結束,啟用);
        li.replaceChild(啟用,結束);

    }


    
    啟用.addEventListener('click', (e) => {
        if (doc.data().狀態 == "已啟用") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要開始了嗎?",
                text: "點確定後更新為處理中!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('equ_announcement').doc(id).update({
                        狀態: "處理中",
                        st:"1",
                        開始時間: firebase.firestore.FieldValue.serverTimestamp(),
                    })

                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 2000);
            });    
        }
      
    })

    結束.addEventListener('click', (e) => {
        if (doc.data().狀態 == "關閉中") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要結束了嗎?",
                text: "點確定後更新為已完成!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('equ_announcement').doc(id).update({
                        狀態: "已完成",
                        st:'2',
                        結束時間: firebase.firestore.FieldValue.serverTimestamp(),
                    })

                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 1300); //1.5秒後自動re
            });    
        }
      
    })

    公告細項.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        li2.appendChild(公告事由);
        li2.appendChild(公告說明);
       
        li.replaceChild(關閉細項, 公告細項);    
    })

    關閉細項.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        li2.removeChild(公告事由);
        li2.removeChild(公告說明);
        li.replaceChild(公告細項, 關閉細項);
       
    })


    公告列表.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        Equprogress.style.marginLeft = '160px'
        回報列表.style.color = '#404040';
        公告列表.style.color = '#127436';
        Equ_Ann_list.style.display = 'block';

        $('#Equ-list').empty();


        項目.remove();
        事由.remove();
        地點.remove();
        狀態.remove();
        buttonfM.style.display ='inline';

        Equ_ann_1.style.display = 'inline';
        Equ_ann_1.style.color ='black';
        Equ_ann_2.style.display = 'inline';
        Equ_ann_2.style.color ='black';
        Equ_ann_3.style.display = 'inline';
        Equ_ann_3.style.color ='black';
        Equ_ann_4.style.display = 'inline';
        Equ_ann_4.style.color ='black';
       

    })

    
    
}


//Equlist
function renderVser(doc) {

    let li = document.createElement('li');
    let recID = document.createElement('span');
    let 申報項目 = document.createElement('span');
    let 申報事由 = document.createElement('span');
    let 報修地點 = document.createElement('span');
    let status = document.createElement('span');
    
    let 接收= document.createElement("button");
    let 處理= document.createElement("button");
    let 完成 = document.createElement("button");
    let FN = document.createElement("button");
    
    let li2 = document.createElement('li2');
    const 照片 = document.createElement('span');
    let 查看附檔 = document.createElement('span');
    let 照片說明 = document.createElement('span');
    let 點擊查看 = document.createElement('span');
    let 點擊關閉 = document.createElement('span');

    
    const img = document.createElement('img');
    img.src = doc.data().照片;
    
    

     //滿意度
    let 星1 = document.createElement('span');
    let 星2 = document.createElement('span');
    let 星3 = document.createElement('span');
    let 星4 = document.createElement('span');
    let 星5 = document.createElement('span');

    let 建議回饋 = document.createElement('span');

    //Time
    let createdAt = document.createElement('span');
    let 已接收時間 = document.createElement('span');
    let 處理中時間 = document.createElement('span');
    let 已完成時間 = document.createElement('span');
    let 結束時間 = document.createElement('span');
   

    let li3 = document.createElement('li3');
    let TS圖gg = document.createElement('span');
    let TS圖gg2 = document.createElement('span');
    let TS圖gg3 = document.createElement('span');
    let TS圖gg4 = document.createElement('span');
    let TS圖 = document.createElement('span');
    let TS圖2 = document.createElement('span');
    let TS圖3 = document.createElement('span');
    let TS圖4 = document.createElement('span');
    let TS圖5= document.createElement('span');
   
    
    
    //Time

    //成立
        var createdAt_Date = doc.data().createdAt.toDate().toLocaleString();

    //接收

        if(doc.data().status =="已接收" ){
            
        var 已接收時間_Date = doc.data().已接收時間.toDate().toLocaleString();
        已接收時間.textContent =   ('接收時間    ' + 已接收時間_Date);

        }else if(doc.data().status =="已完成"){

        var 已接收時間_Date = doc.data().已接收時間.toDate().toLocaleString();
        var 處理中時間_Date = doc.data().處理中時間.toDate().toLocaleString();
        var 已完成時間_Date = doc.data().已完成時間.toDate().toLocaleString();


         已接收時間.textContent =   ('接收時間    ' + 已接收時間_Date);
         處理中時間.textContent =   ('處理時間    ' + 處理中時間_Date);
         已完成時間.textContent = ('完成時間    ' + 已完成時間_Date);

           
        }else if(doc.data().status =="已結束"){

        var 已接收時間_Date = doc.data().已接收時間.toDate().toLocaleString();
        var 處理中時間_Date = doc.data().處理中時間.toDate().toLocaleString();
        var 已完成時間_Date = doc.data().已完成時間.toDate().toLocaleString();
        var 結束時間_Date = doc.data().結束時間.toDate().toLocaleString();

        已接收時間.textContent =   ('接收時間    ' + 已接收時間_Date);
        處理中時間.textContent =   ('處理時間    ' + 處理中時間_Date);
        已完成時間.textContent = ('完成時間    ' + 已完成時間_Date);
        結束時間.textContent =   ('結束時間    ' + 結束時間_Date);

        }else if(doc.data().status =="成立中"){

       

        }else if(doc.data().status =="處理中"){

        var 已接收時間_Date = doc.data().已接收時間.toDate().toLocaleString();
        var 處理中時間_Date = doc.data().處理中時間.toDate().toLocaleString();

        已接收時間.textContent =   ('接收時間    ' + 已接收時間_Date);
        處理中時間.textContent =   ('處理時間    ' + 處理中時間_Date);

            
        }

   

    //動工
   

    //完工
   

    //結束
   
    console.log(createdAt_Date);


    //ID

    li.setAttribute('data-id', doc.id);
    li2.setAttribute('data-id', doc.id);
    li3.setAttribute('data-id', doc.id);
    申報項目.textContent = (doc.data().申報項目);
    申報事由.textContent = (doc.data().申報事由);
    recID.textContent = (doc.data().recID);
    報修地點.textContent = (doc.data().報修地點);
    status.textContent = (doc.data().status);
    照片.textContent = (doc.data().照片);
    照片說明.textContent = ('說明 : '+ doc.data().說明);
    點擊查看.textContent = '查看細項';
    點擊關閉.textContent = '關閉細項';
    
    接收.textContent = '接收';
    處理.textContent = '處理';
    完成.textContent = '完成';
    FN.textContent = '結束';

    TS圖.textContent  = '◎ 成立中';
    TS圖2.textContent = '◎ 處理中';
    TS圖3.textContent = '◎ 已完成';
    TS圖4.textContent = '◎ 已結束';
    TS圖5.textContent = '◎ 已接收';
    TS圖gg.textContent  = ' → ';
    TS圖gg2.textContent = ' → ';
    TS圖gg3.textContent = ' → ';
    TS圖gg4.textContent = ' → ';

    星1.textContent = '滿意度 : ★';
    星2.textContent = '滿意度 : ★★';
    星3.textContent = '滿意度 : ★★★';
    星4.textContent = '滿意度 : ★★★★';
    星5.textContent = '滿意度 : ★★★★★';

    建議回饋.textContent = ('建議回饋 : '+ doc.data().建議回饋);
   
    
    createdAt.textContent = ('報修時間    ' + createdAt_Date);
    
   
   

    //List

    li.appendChild(申報項目);
    li.appendChild(申報事由);
    li.appendChild(報修地點);
    li.appendChild(status);
    li.appendChild(點擊查看);
    li.appendChild(接收);

    Equlist.appendChild(li);
    Equlist.appendChild(li3);
    Equlist.appendChild(li2);
    
    //btn回報列表

    回報列表.addEventListener('click', (e) => {

        let id = e.target.parentElement.getAttribute('data-id');

        sessionStorage.setItem("key", id);
        回報列表.style.color = '#127436';
        公告列表.style.color = '#404040';
        Equprogress.style.marginLeft = '10px'

         $('#Equ-Ann-list').empty();
         setTimeout(function(){window.location.reload();}, 200);
       
})

    

    點擊查看.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        li3.appendChild(TS圖);
        li3.appendChild(TS圖gg);
        li3.appendChild(TS圖5);
        li3.appendChild(TS圖gg4);
        li3.appendChild(TS圖2);
        li3.appendChild(TS圖gg2);
        li3.appendChild(TS圖3);
        li3.appendChild(TS圖gg3);
        li3.appendChild(TS圖4);
        li2.appendChild(img);
        li2.appendChild(照片說明);
        li2.appendChild(建議回饋);          
        li.replaceChild(點擊關閉, 點擊查看);


//////////
        if(doc.data().status =="已接收" ){
            
            li2.appendChild(createdAt);
            li2.appendChild(已接收時間);
        

        }else if(doc.data().status =="已完成"){

            li2.appendChild(createdAt);
            li2.appendChild(已接收時間);
            li2.appendChild(處理中時間);
            li2.appendChild(已完成時間);

        }else if(doc.data().status =="已結束"){

            li2.appendChild(createdAt);
            li2.appendChild(已接收時間);
            li2.appendChild(處理中時間);
            li2.appendChild(已完成時間);
            li2.appendChild(結束時間);


            if(doc.data().滿意度 =="1"){
                li2.appendChild(星1);
                li2.appendChild(建議回饋);

            }else if(doc.data().滿意度 =="2"){
                li2.appendChild(星2);
                li2.appendChild(建議回饋);

            }else if(doc.data().滿意度 =="3"){
                li2.appendChild(星3);
                li2.appendChild(建議回饋);

            }else if(doc.data().滿意度 =="4"){
                li2.appendChild(星4);
                li2.appendChild(建議回饋);

            }else if(doc.data().滿意度 =="5"){
                li2.appendChild(星5);
                li2.appendChild(建議回饋);

            }

        }else if(doc.data().status =="成立中"){

            li2.appendChild(createdAt);

        }else if(doc.data().status =="處理中"){

             li2.appendChild(createdAt);
             li2.appendChild(已接收時間);
             li2.appendChild(處理中時間);
        }

    })

    點擊關閉.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        li3.removeChild(TS圖);
        li3.removeChild(TS圖gg);
        li3.removeChild(TS圖2);
        li3.removeChild(TS圖gg2);
        li3.removeChild(TS圖3);
        li3.removeChild(TS圖gg3);
        li3.removeChild(TS圖4);
        li2.removeChild(img);
        li3.removeChild(TS圖5);
        li2.removeChild(照片說明);
        li2.removeChild(建議回饋);
        li3.removeChild(TS圖gg4);

        li.replaceChild(點擊查看, 點擊關閉);    

////
         if(doc.data().status =="已接收" ){
            
            li2.removeChild(createdAt);
            li2.removeChild(已接收時間);
        

        }else if(doc.data().status =="已完成"){

            li2.removeChild(createdAt);
            li2.removeChild(已接收時間);
            li2.removeChild(處理中時間);
            li2.removeChild(已完成時間);

        }else if(doc.data().status =="已結束"){

            li2.removeChild(createdAt);
            li2.removeChild(已接收時間);
            li2.removeChild(處理中時間);
            li2.removeChild(已完成時間);
            li2.removeChild(結束時間);


            if(doc.data().滿意度 =="1"){
                li2.removeChild(星1);
                

            }else if(doc.data().滿意度 =="2"){
                li2.removeChild(星2);
                

            }else if(doc.data().滿意度 =="3"){
                li2.removeChild(星3);
                

            }else if(doc.data().滿意度 =="4"){
                li2.removeChild(星4);
                

            }else if(doc.data().滿意度 =="5"){
                li2.removeChild(星5);
               

            }

        }else if(doc.data().status =="成立中"){

            li2.removeChild(createdAt);

        }else if(doc.data().status =="處理中"){

             li2.removeChild(createdAt);
             li2.removeChild(已接收時間);
             li2.removeChild(處理中時間);
        }
    })

    //字體顏色

     if(doc.data().status =="處理中" ){

        status.style.color = 'red';
        TS圖2.style.color = 'red';

        li.replaceChild(處理,接收);
        li.replaceChild(完成,處理);

    }else if(doc.data().status =="已完成"){

        
        TS圖3.style.color = 'red';
        status.style.color= '#BB5E00'
        li.replaceChild(處理,接收);
        li.replaceChild(完成,處理);
        完成.style.cursor = "not-allowed";
        完成.disabled = "true";

    }else if(doc.data().status =="已結束"){

       TS圖4.style.color = 'red';
       status.style.color = 'blue';
       li.replaceChild(處理,接收);
       li.replaceChild(完成,處理);
       li.replaceChild(FN,完成);
       FN.style.cursor = "not-allowed";
       FN.disabled = "true";

    }else if(doc.data().status =="已成立"){

        status.style.color = 'black';
        TS圖.style.color = 'red';

    }else if(doc.data().status =="已接收"){

        TS圖5.style.color = 'red';
        status.style.color = 'black';

        li.replaceChild(處理,接收);
       }


     
    //啟用狀態

    接收.addEventListener('click', (e) => {
        if (doc.data().status == "已接收") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要更新狀態了嗎?",
                text: "點確定後更新為已接收!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('equipmentReport').doc(id).update({
                        status: "已接收",
                        stat_lv:"2",
                        已接收時間: firebase.firestore.FieldValue.serverTimestamp(),
                    })

                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 1300);
            });    
        }
      
    })


    處理.addEventListener('click', (e) => {
        if (doc.data().status == "處理中") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要更新狀態了嗎?",
                text: "點確定後更新為處理中!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('equipmentReport').doc(id).update({
                        status: "處理中",
                        stat_lv:"3",
                        處理中時間: firebase.firestore.FieldValue.serverTimestamp(),
                    })

                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 1300);
            });    
        }
      
    })

    完成.addEventListener('click', (e) => {
        if (doc.data().status == "已完成") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要更新狀態了嗎?",
                text: "點確定後更新為已完成!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('equipmentReport').doc(id).update({
                        status: "已完成",
                        stat_lv:"4",
                        已完成時間: firebase.firestore.FieldValue.serverTimestamp(),
                    })

                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 1300); //1.5秒後自動re
            });    
        }
      
    })

     FN.addEventListener('click', (e) => {
        if (doc.data().status == "已結束") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要更新狀態了嗎?",
                text: "點確定後更新為已結束!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('equipmentReport').doc(id).update({
                        status: "已結束",
                        stat_lv:"5",
                        結束時間: firebase.firestore.FieldValue.serverTimestamp(),
                    })

                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 1300); //1.5秒後自動re
            });    
        }
      
    })

}

//反饋db
db.collection('equipmentReport').orderBy('createdAt', 'desc').onSnapshot(snapshot => {

    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if (change.type == 'added') {
            renderVser(change.doc);
        } else if (change.type == 'removed') {
            let li = Equlist.querySelector('[data-id=' + change.doc.id + ']');
            Equlist.removeChild(li);
        }
    });
});

//公告db
db.collection('equ_announcement').orderBy('createdAt', 'desc').onSnapshot(snapshot => {

    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if (change.type == 'added') {
            fMrenderVser(change.doc);
        } else if (change.type == 'removed') {
            let li = Equ_Ann_list.querySelector('[data-id=' + change.doc.id + ']');
            Equ_Ann_list.removeChild(li);
        }
    });

});



//彈出式表單

var Equ1 = document.getElementById("Equ1");
var Cancel = document.getElementById("Cancel");
const Equ_標題 = document.getElementById('Equ_標題');
const Equ_項目 = document.getElementById('Equ_項目');
const Equ_事由 = document.getElementById('Equ_事由');
const Equ_地點 = document.getElementById('Equ_地點');
const Equ_Remarks = document.getElementById('Equ_Remarks');
var buttonfM = document.getElementById("buttonfM");


Cancel.onclick = function(){

    document.querySelector('.bg-modal').style.display = 'none';
    document.documentElement.style.overflowY = 'scroll'; 
    location.reload();
    
}

//open form
document.getElementById('buttonfM').addEventListener('click',
    function(){
        document.querySelector('.bg-modal').style.display = 'flex';
        document.documentElement.style.overflowY = 'hidden'; 

    });


//Add 新增

const Submit = document.getElementById("Submit");
console.log(AdminId);
const database2 = firebase.firestore();
const usersCollection = database2.collection('equ_announcement');
var docRef = database2.collection("admin").doc(AdminId);
var ImgName;
var ImgUrl;

docRef.get().then((doc) => {  
    if (doc.exists) {
        console.log("Document data:", doc.data());
        AdminName = doc.data().name;
        console.log(AdminName);

        Submit.addEventListener('click', e => {
           
           if (Equ_標題.value === null || Equ_標題.value === '' || Equ_項目.value === null || Equ_項目.value === ''|| Equ_事由.value === null || Equ_事由.value === ''|| Equ_地點.value === null || Equ_地點.value === '') {
                swal("請輸入標題內容");
            } else {
                e.preventDefault();
                console.log(JSON.stringify(firebase.storage))
                const ref = firebase.storage().ref();
                const file = document.querySelector("#photo").files[0];
                const name = file.name;
                const metadata = {
                    contentType: file.type
                };
                const task = ref.child(name).put(file, metadata);
                task
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then(url => {

                        console.log(url);
                        const ID = usersCollection.doc().set({
                            標題: Equ_標題.value,
                            項目: Equ_項目.value,
                            事由: Equ_事由.value,
                            說明: Equ_Remarks.value,
                            報修地點: Equ_地點.value,
                            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                            createdBy: AdminName,
                            狀態: '待處理',
                            照片: url,

                        }).then(() => {
                            console.log('Data has been saved successfully !');
                                document.querySelector('.bg-modal').style.display = 'none';
                                document.documentElement.style.overflowY = 'scroll'; 
                                setTimeout(function(){window.location.reload();}, 100);
                        })
                        swal({
                            title: "Good job!",
                            text: "You clicked the button!",
                            icon: "success",
                            button: "Send successfully!",
                        }).catch(error => {
                            console.error(error)
                        });
                        document.querySelector("#image").src = url;
                    })
                    .catch(console.error);

            }   
        });
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

//轉換頁面

var 回報列表 = document.getElementById('equ_list');
var 公告列表 = document.getElementById('equ_annlist');
var link_top = document.getElementById('link-top');

回報列表.style.color = '#127436';

//replace

var 項目 = document.getElementById('Equ_1');
var 事由 = document.getElementById('Equ_2');
var 地點 = document.getElementById('Equ_3');
var 狀態 = document.getElementById('Equ_4');

var Equ_ann_標題 = document.getElementById('Equ_ann_1');
var Equ_ann_項目 = document.getElementById('Equ_ann_2');

var Equ_ann_地點 = document.getElementById('Equ_ann_3');
var Equ_ann_狀態 = document.getElementById('Equ_ann_4');


