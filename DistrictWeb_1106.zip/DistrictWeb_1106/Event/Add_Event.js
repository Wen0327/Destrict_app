const 活動名稱= document.getElementById('Add_event_name');
const 活動費用 = document.getElementById('Add_event_money');
const 活動限制人數 = document.getElementById('Add_event_nop');
const 活動內容 = document.getElementById('Add_ev_content');
const 活動地點 = document.getElementById('Add_event_place')
const 活動主辦人 = document.getElementById('Add_event_host');
const 報名開始日期 = document.getElementById('r_s_datepick');
const 報名開始時間 = document.getElementById('r_s_timepick');
const 報名截止日期 = document.getElementById('r_e_datepick');
const 報名截止時間 = document.getElementById('r_e_timepick');
const 活動開始日期 = document.getElementById('e_s_datepick');
const 活動開始時間 = document.getElementById('e_s_timepick');
const 活動截止日期 = document.getElementById('e_e_datepick');
const 活動截止時間 = document.getElementById('e_e_timepick');


const Submit = document.getElementById("Submit");
console.log(AdminId);
const database2 = firebase.firestore();
const usersCollection = database2.collection('event');
var docRef = database2.collection("admin").doc(AdminId);


    docRef.get().then((doc) => {  
    if (doc.exists) {
        console.log("Document data:", doc.data());
        AdminName = doc.data().name;
        console.log(AdminName);

        Submit.addEventListener('click', e => {
           
           if (活動名稱.value === null || 活動名稱.value === '' ||  活動費用.value === null || 活動費用.value === '' || 活動限制人數.value === null || 活動限制人數.value === ''|| 活動內容.value === null || 活動內容.value === ''|| 活動地點.value === null || 活動地點.value === ''|| 活動主辦人.value === null || 活動主辦人.value === '') {
                swal("請輸入標題內容");
            } else {
                e.preventDefault();
                const ref = firebase.storage().ref();
                const file = document.querySelector("#photo").files[0];
                const name = file.name;
                const metadata = {
                    contentType: file.type
                };
                const task = ref.child(name).put(file, metadata);
                task
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then(url => {

                        console.log(url);
                        const ID = usersCollection.doc().set({
                                event_name: 活動名稱.value,
                                cost: 活動費用.value,
                                NOP: 活動限制人數.value,
                                content: 活動內容.value,
                                location: 活動地點.value,
                                host: 活動主辦人.value,
                                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                                createdBy: AdminName,
                                registration_start_Date: 報名開始日期.value+報名開始時間.value,
                                registration_start_Timestamp : firebase.firestore.Timestamp.fromDate(new Date(報名開始日期.value+報名開始時間.value)),
                                registration_end_Date: 報名截止日期.value+報名截止時間.value,
                                registration_end_Timestamp : firebase.firestore.Timestamp.fromDate(new Date(報名截止日期.value+報名截止時間.value)),
                                event_start_time: 活動開始日期.value+活動開始時間.value,
                                event_start_Timestamp:firebase.firestore.Timestamp.fromDate(new Date(活動開始日期.value+活動開始時間.value)),
                                event_end_time: 活動截止日期.value+活動截止時間.value,
                                event_end_Timestamp:firebase.firestore.Timestamp.fromDate(new Date(活動截止日期.value+活動截止時間.value)),
                                status : "未開放",
                                img: url,
                                or:"1",
                                NNOP:'0',

                        }).then(() => {
                            console.log('Data has been saved successfully !');
                            setTimeout(function(){window.location.href = 'event_v2.html'}, 1300);
                        })
                        swal({
                            title: "Good job!",
                            text: "You clicked the button!",
                            icon: "success",
                            button: "Send successfully!",
                        }).catch(error => {
                            console.error(error)
                        });
                        document.querySelector("#image").src = url;
                    })
                    .catch(console.error);

            }   
        });
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});