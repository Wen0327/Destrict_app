//名稱限30w
//

const EventList = document.querySelector('#ev_list');
const AddList = document.querySelector('#add_ev_list');
var storageRef = firebase.storage().ref(); 
const key = sessionStorage.getItem('key');
console.log(key);

//li 目前活動
function renderVser(doc){
    let li = document.createElement('li');
    let event_name = document.createElement('span');
    let content = document.createElement('span');
    let cost = document.createElement('span');
    let host = document.createElement('span');
    let NOP = document.createElement('span');
    let nowp = document.createElement('span');

    
  
    ////////////////////////////////////////////////////////////// 活動
    let event_time = document.createElement('span');
    var e_s_d_1 = doc.data().event_start_Timestamp.toDate().toLocaleDateString();
    var e_s_d = doc.data().event_start_Timestamp.toDate().toLocaleString([],{hour: '2-digit', minute:'2-digit'});

    var e_d_1 = doc.data().event_end_Timestamp.toDate().toLocaleDateString();
    var e_e_d = doc.data().event_end_Timestamp.toDate().toLocaleString([],{hour: '2-digit', minute:'2-digit'});

    ////////////////////////////////////////////////////////////// 報名
    let re_time = document.createElement('span');
    var re_s_d_1 = doc.data().registration_start_Timestamp.toDate().toLocaleDateString();
    var re_s_d = doc.data().registration_start_Timestamp.toDate().toLocaleString([],{hour: '2-digit', minute:'2-digit'});

    var re_d_1 = doc.data().registration_end_Timestamp.toDate().toLocaleDateString();
    var re_e_d = doc.data().registration_end_Timestamp.toDate().toLocaleString([],{hour: '2-digit', minute:'2-digit'});

    //////////////////////////////////////////////////////////////
    let createdAt = document.createElement('span');
    var createdAt_Date = doc.data().createdAt.toDate().toLocaleString();
    let li2 = document.createElement('li2');

//圖片
  const displayImg = (url, width, height,) => {
  const img = document.createElement('img');
  img.src = doc.data().img;
  EventList.appendChild(img);
}



//get Unique ID
    li.setAttribute('data-id', doc.id);
    li2.setAttribute('data-id', doc.id);
    event_name.textContent = (doc.data().event_name);
    content.textContent = (doc.data().content);
    cost.textContent =("【費用】"+ doc.data().cost);
    host.textContent =("【主辦人】"+ doc.data().host);
    NOP.textContent = ("【人數限制】"+ doc.data().NNOP+'/'+doc.data().NOP);
    createdAt.textContent = ("資料創建時間:" + createdAt_Date);
    event_time.textContent = ("【活動時間】"+e_s_d_1 + e_s_d +" ~ "+e_d_1 + e_e_d);
    re_time.textContent = ("【報名時間】"+re_s_d_1 + re_s_d +" ~ "+re_d_1+ re_e_d);

    


    ///


        
    li.appendChild(event_name);
    li2.appendChild(host);
    li2.appendChild(cost);
    li2.appendChild(NOP); 
    li2.appendChild(re_time);
    li2.appendChild(event_time);
    li2.appendChild(createdAt);
    EventList.appendChild(li);
    displayImg();

    
   
    EventList.appendChild(li2);

    //判定狀態
   
    let nt = moment().valueOf();

    console.log(nt);

    var 報名開始時間 = doc.data().registration_start_Timestamp.toDate().getTime();
    var 報名結束時間 = doc.data().registration_end_Timestamp.toDate().getTime();
    var 活動開始時間 = doc.data().event_start_Timestamp.toDate().getTime();
    var 活動結束時間 = doc.data().event_end_Timestamp.toDate().getTime();

   
    
        if(報名開始時間 < nt ){
             an_db.collection('event').doc(doc.id).update({
                  status: "報名開始",})
        }

        if(報名結束時間  < nt ){
             an_db.collection('event').doc(doc.id).update({
                  status: "報名結束",})
        }

        if(活動開始時間  < nt ){
                 an_db.collection('event').doc(doc.id).update({
                      status: "活動開始",})
        }

        if(活動結束時間  < nt ){
                 an_db.collection('event').doc(doc.id).update({
                      status: "活動結束",
                      or :"2",

                  })
         }

    //open all

    event_name.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        location.href = "open_event.html";
})
    
}

an_db.collection('event').where("or", "==", "1").onSnapshot(snapshot => {

    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if (change.type == 'added') {
            renderVser(change.doc);
        } else if (change.type == 'removed') {
            
            EventList.removeChild(li);
        }
    });


});

///////


//count nop


an_db.collection('event').where("or", "==", "1").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
           
    an_db.collection('event').doc(doc.id).collection('Sign up').get().then((querySnapshot) => {

        let total_count = 0;
        
        querySnapshot.forEach((doc) => {
            
        total_count += doc.data().nop;
       
        });

        an_db.collection('event').doc(doc.id).update({
                        
        NNOP:total_count,

        });

        console.log(total_count);
        return total_count;
    
});

    });
});





