
const usersCollection = database.collection('event');
const doc_key= sessionStorage.getItem('key');
console.log(doc_key);
var docRef2 = database.collection("event").doc(doc_key);


docRef2.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        ///

        let li = document.createElement('li');

      ////////////////////////////////////////////////////////////// 活動
      var e_s_d_1 = doc.data().event_start_Timestamp.toDate().toLocaleDateString();
      var e_s_d = doc.data().event_start_Timestamp.toDate().toLocaleString([],{hour: '2-digit', minute:'2-digit'});

     var e_d_1 = doc.data().event_end_Timestamp.toDate().toLocaleDateString();
     var e_e_d = doc.data().event_end_Timestamp.toDate().toLocaleString([],{hour: '2-digit', minute:'2-digit'});


      ////////////////////////////////////////////////////////////// 報名
      var re_s_d_1 = doc.data().registration_start_Timestamp.toDate().toLocaleDateString();
      var re_s_d = doc.data().registration_start_Timestamp.toDate().toLocaleString([],{hour: '2-digit', minute:'2-digit'});

      var re_d_1 = doc.data().registration_end_Timestamp.toDate().toLocaleDateString();
      var re_e_d = doc.data().registration_end_Timestamp.toDate().toLocaleString([],{hour: '2-digit', minute:'2-digit'});


     

       console.log(e_s_d);

		document.getElementById('event_name').innerHTML =(doc.data().event_name);
		document.getElementById('e_t').innerHTML =("【活動時間】"+e_s_d_1 + e_s_d +" ~ "+e_d_1 + e_e_d);
        document.getElementById('re_t').innerHTML =("【報名時間】"+re_s_d_1 + re_s_d +" ~ "+re_d_1+ re_e_d);
        document.getElementById('cost').innerHTML =("【費用】"+ doc.data().cost);
        document.getElementById('host').innerHTML =("【主辦人】"+doc.data().host);
        document.getElementById('NOP').innerHTML =("【人數限制】"+ doc.data().NOP);
        document.getElementById('content').innerHTML =("【內文】"+ doc.data().content);
        
		const img = document.createElement('img');
		  img.src = doc.data().img;
		  document.getElementById("img").appendChild(img);


    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

