const SuggestionList = document.querySelector('#Suggestion-list');
const key = sessionStorage.getItem('key');
const nn = document.getElementById('n');
const yy = document.getElementById('y');
const all = document.getElementById('all');
console.log(key);


function renderVser(doc) {
    let li = document.createElement('li');
    let li2 = document.createElement('li2');

    let title = document.createElement('div');
    let name = document.createElement('span');
    let recID = document.createElement('span');
    let content = document.createElement('span');
    let admin_name = document.createElement('span');
    let response_content = document.createElement('span');
    let response_status = document.createElement('span');

    let createdAt = document.createElement('span');
    let response_time = document.createElement('span');

    let cross = document.createElement('div');
    let ed = document.createElement('div3')

    //Time
    var createdAt_Date = doc.data().createdAt.toDate().toLocaleString();
    console.log(createdAt_Date);

    var response_Date = doc.data().response_time.toDate().toLocaleString();
    console.log(response_Date);

    //ID
    li.setAttribute('data-id', doc.id);
    li2.setAttribute('data-id', doc.id);
    title.textContent = (doc.data().title);
    name.textContent = ("Name : " + doc.data().name);
    recID.textContent = ("recID : " + doc.data().recID);
    content.textContent = ("意見內容 : " + doc.data().content);
    //2個時間待補
    admin_name.textContent = ("Admin : " + doc.data().admin_name);
    response_content.textContent = ("管理員回覆 : " + doc.data().response_content);
    response_status.textContent = ("狀態 : " + doc.data().response_status);
    createdAt.textContent = (createdAt_Date);
    response_time.textContent = ("回覆時間 : " + response_Date);

    cross.textContent = 'Back';
    ed.textContent = 'Reply';


    //List

    li.appendChild(title);
    li2.appendChild(response_status);

    li2.appendChild(name);
    li2.appendChild(recID);
    li2.appendChild(createdAt);

    
    SuggestionList.appendChild(li);

    SuggestionList.appendChild(li2);

    //

    title.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        li2.appendChild(content);
        li2.appendChild(ed);
        li2.appendChild(admin_name);
        li2.appendChild(response_content);
        li2.appendChild(response_time);

        li.replaceChild(cross,title);      
    })

    cross.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        li2.removeChild(content);
        li2.removeChild(ed);
        li2.removeChild(admin_name);
        li2.removeChild(response_content);
        li2.removeChild(response_time);
        li.replaceChild(title,cross);
       
    })

    //



    ed.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        location.href = "SUGRE.html";

    })



}



db.collection('Suggestion').where('response_status', '==', '未回覆').orderBy('createdAt', 'desc').onSnapshot(snapshot => {

    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if (change.type == 'added') {
            renderVser(change.doc);
        } else if (change.type == 'removed') {
            let li = SuggestionList.querySelector('[data-id=' + change.doc.id + ']');
            SuggestionList.removeChild(li);
        }
    });

});
nn.addEventListener('click', (e) => {
    $('#Suggestion-list').empty();
    db.collection('Suggestion').where('response_status', '==', '未回覆').orderBy('createdAt', 'desc').onSnapshot(snapshot => {

        let changes = snapshot.docChanges();
        changes.forEach(change => {
            if (change.type == 'added') {
                renderVser(change.doc);
            } else if (change.type == 'removed') {
                let li = SuggestionList.querySelector('[data-id=' + change.doc.id + ']');
                SuggestionList.removeChild(li);
            }
        });

    });

})
yy.addEventListener('click', (e) => {
    $('#Suggestion-list').empty();
    db.collection('Suggestion').where('response_status', '==', '已回覆').orderBy('createdAt', 'desc').onSnapshot(snapshot => {

        let changes = snapshot.docChanges();
        changes.forEach(change => {
            if (change.type == 'added') {
                renderVser(change.doc);
            } else if (change.type == 'removed') {
                let li = SuggestionList.querySelector('[data-id=' + change.doc.id + ']');
                SuggestionList.removeChild(li);
            }
        });

    });

})
all.addEventListener('click', (e) => {
    $('#Suggestion-list').empty();
    db.collection('Suggestion').orderBy('createdAt', 'desc').onSnapshot(snapshot => {

        let changes = snapshot.docChanges();
        changes.forEach(change => {
            if (change.type == 'added') {
                renderVser(change.doc);
            } else if (change.type == 'removed') {
                let li = SuggestionList.querySelector('[data-id=' + change.doc.id + ']');
                SuggestionList.removeChild(li);
            }
        });

    });

})