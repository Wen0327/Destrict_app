const addBtn = document.getElementById('addBtn');
const backBtn = document.getElementById('backBtn');


const usersCollection = an_db.collection('Suggestion');
const doc_key= sessionStorage.getItem('key');
console.log(doc_key);



console.log(AdminId);
var AdminName;

var docRef = an_db.collection("admin").doc(AdminId);

docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        AdminName = doc.data().name;
        console.log(AdminName);
        }
      })



var docRef = an_db.collection("Suggestion").doc(doc_key);
var name2;
var recID2;
var title2;
var content2;
var response_content2;


addBtn.addEventListener('click', e => {

  e.preventDefault();
    const ID = usersCollection.doc(doc_key).update({

    title: Title.value,
    name: Name.value,
    recID: recID.value,
    content: Content.value,
    response_content: ResponseContent.value,
    response_time: firebase.firestore.FieldValue.serverTimestamp(),
    response_status:"已回覆",
    admin_name:AdminName,
    
 
  })
  .then(()=>{ 
    console.log('Data has been saved successfully !')})
    swal({
  title: "Good job!",
  text: "You clicked the button!",
  icon: "success",
  button: "Send successfully!",
})
  .catch(error => {
    console.error(error)
  });
});


backBtn.addEventListener('click', e => {
location.href = "Suggestion.html";

 });


docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());

        title2 = doc.data().title;
        console.log(title2);
        name2 = doc.data().name;
        console.log(name2);
        recID2 = doc.data().recID;
        console.log(recID2);
        content2 = doc.data().content;
        console.log(content2);
        response_content2 = doc.data().response_content;
        console.log(response_content2);

        var Title =  document.getElementById('Title').value += title2;
        var Name = document.getElementById('Name').value += name2;
        var recID = document.getElementById('recID').value += recID2;
        var Content = document.getElementById('Content').value += content2;
        var ResponseContent = document.getElementById('ResponseContent').value += response_content2;
        
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

