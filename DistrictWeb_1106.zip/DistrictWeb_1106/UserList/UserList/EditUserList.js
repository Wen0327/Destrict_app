
const addBtn = document.getElementById('addBtn');
const backBtn = document.getElementById('backBtn');


const usersCollection = an_db.collection('users');
const doc_key= sessionStorage.getItem('key');
console.log(doc_key);
var docRef = an_db.collection("users").doc(doc_key);
var user_name2;
var EditEmail2;
var ChangePassword2;

var EditBuilding2;
var EditFloor2;
var EditDoor2;
var EditrecID2;

var EditAddress2;
var EditPhoneNumber2;



addBtn.addEventListener('click', e => {

  e.preventDefault();
    const ID = usersCollection.doc(doc_key).update({


    recID:  EditrecID.value,
    building: EditBuilding.value,
    floor: EditFloor.value,
    door: EditDoor.value,

    user_name: user_name.value,
    email: EditEmail.value,
    password: ChangePassword.value,

    address: EditAddress.value,
    phone: EditPhoneNumber.value,

    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
 
  })
  .then(()=>{ 
    console.log('Data has been saved successfully !')})
    swal({
  title: "Good job!",
  text: "You clicked the button!",
  icon: "success",
  button: "Send successfully!",
})
  .catch(error => {
    console.error(error)
  });
});


backBtn.addEventListener('click', e => {
location.href = "UserList.html";

 });


docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());

        EditrecID2 = doc.data().recID;
        console.log(EditrecID2);

        EditBuilding2 = doc.data().building;
        console.log(EditBuilding2);
        EditFloor2 = doc.data().floor;
        console.log(EditFloor2);
        EditDoor2 = doc.data().door;
         console.log(EditDoor2);

        user_name2 =  doc.data().user_name;
        console.log(user_name2);
        EditEmail2 = doc.data().email;
        console.log(EditEmail2);
        ChangePassword2 = doc.data().password;
        console.log(ChangePassword2);

        EditAddress2 = doc.data().address;
        console.log(EditAddress2);
        EditPhoneNumber2 = doc.data().phone;
        console.log(EditPhoneNumber2);


        var EditrecID =  document.getElementById('EditrecID').value += EditrecID2;

        var EditBuilding = document.getElementById('EditBuilding').value += EditBuilding2;
        var EditFloor = document.getElementById('EditFloor').value += EditFloor2;
        var EditDoor = document.getElementById('EditDoor').value += EditDoor2;

        var user_name = document.getElementById('user_name').value += user_name2;
        var EditEmail = document.getElementById('EditEmail').value += EditEmail2;
        var ChangePassword = document.getElementById('ChangePassword').value += ChangePassword2;

        var EditAddress =  document.getElementById('EditAddress').value += EditAddress2;
        var EditPhoneNumber =  document.getElementById('EditPhoneNumber').value += EditPhoneNumber2;
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

