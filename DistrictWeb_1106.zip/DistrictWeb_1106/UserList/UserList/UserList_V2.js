const userList = document.querySelector('#user-list');
const form = document.querySelector('#add-user-form');



// create element & render user
function renderUser(doc){
    let li = document.createElement('li');
    let user_name = document.createElement('span');
    let email = document.createElement('span');
    let password = document.createElement('span');
    let address = document.createElement('span');
    let phone = document.createElement('span');
    let time = document.createElement('span');
    let cross = document.createElement('div');
    let up = document.createElement('div2');

    let recID = document.createElement('span');

    //圖片
    const displayImg = (url, width, height,) => {
    const img = document.createElement('img');
    img.src = doc.data().照片;
    userList.appendChild(img);
    }
   

    var readableDate = doc.data().createdAt.toDate().toLocaleString();

//get Unique ID
    li.setAttribute('data-id', doc.id);
    user_name.textContent = ("Name : "+doc.data().user_name);
    email.textContent = ("Email : "+doc.data().email);
    password.textContent = ("Password  : "+doc.data().password);
    address.textContent = ("address : "+doc.data().address);
    phone.textContent = ("phone : "+doc.data().phone);
    cross.textContent = ' ';
    up.textContent = ' ';
    recID.textContent = ("ID : "+doc.data().recID);
    time.textContent = ("最後修改時間 : "+readableDate);

    

    li.appendChild(recID);
    li.appendChild(user_name);
    li.appendChild(address);
    li.appendChild(phone);
    li.appendChild(email);
    li.appendChild(password);
    li.appendChild(time);
    displayImg();

    
    li.appendChild(up);
    li.appendChild(cross);

    userList.appendChild(li);

    // deleting data
    cross.addEventListener('click', (e) => {
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('users').doc(id).delete();
                    swal("Poof! Your imaginary file has been deleted!", {
                        icon: "success",
                    });
                } else {
                    swal("Your imaginary file is safe!");
                }
            });

    });



     up.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        location.href = "EdUserInfo.html";
})


}

// getting data
//Queries:  db.collection('UsersTest').where('?','==','?').orderBy('name').get()
// set up index inside the firebase to Enable 


//real-time listener to listen changes
db.collection('users').orderBy('user_name').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if(change.type == 'added'){
            renderUser(change.doc);
        } else if (change.type == 'removed'){
            let li =userList.querySelector('[data-id=' + change.doc.id + ']');
            userList.removeChild(li);
        }

    })
})

// saving data 
/*
form.addEventListener('submit', (e) => {
    
    e.preventDefault();  //not to refresh page
    db.collection('users').add({
        user_name: form.user_name.value,
        email: form.email.value,       
    });
    form.user_name.value = '';
    form.email.value = '';
});
*/

