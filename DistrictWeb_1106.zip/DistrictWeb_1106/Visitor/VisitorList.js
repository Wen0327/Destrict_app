const visitorList = document.querySelector('#visitor-list');
const searchBtn = document.getElementById('searchBtn');
const searchtext = document.getElementById('searchtext');
const key = sessionStorage.getItem('key');
const choice = sessionStorage.getItem('choice');


console.log(key);


// create element & render user
function renderVser(doc){
    let li = document.createElement('li');
   
    let visitor_name = document.createElement('span');
  

    let phone = document.createElement('span');
    let recID = document.createElement('span');
  
    let visitor_status =  document.createElement('span');
    let actual_arrival_time = document.createElement('span');
    let actual_leave_time = document.createElement('span');
    let expected_arrive_time = document.createElement('span');
    let expected_leave_time = document.createElement('span');
  


    let cross = document.createElement('div');
    //離開    
    let lv = document.createElement('div2');
   
    // 抵達
    let accepted = document.createElement('div3');

   

    var expected_arrive_Date = doc.data().expected_arrive_time.toDate().toLocaleString();
    console.log(expected_arrive_Date);

    var expected_leave_Date = doc.data().expected_leave_time.toDate().toLocaleString();
    console.log(expected_leave_Date);

    //抵達時間
     var actual_arrival_Date = doc.data().actual_arrival_time.toDate().toLocaleString();
     console.log(actual_arrival_Date);

    // 離開時間
     var actual_leave_Date = doc.data().actual_leave_time.toDate().toLocaleString();
     console.log(actual_leave_Date);
     

   // var readableDate = doc.data().createdAt.toDate();
    //console.log(readableDate);
    

//get Unique ID
    li.setAttribute('data-id', doc.id);
   
    visitor_name.textContent = ("訪客名稱 : "+doc.data().visitor_name);
   
   phone.textContent = ("聯絡電話 : "+doc.data().phone);
   visitor_status.textContent = ("狀態: " +doc.data().visitor_status);



    cross.textContent = ' ';
  
    lv.textContent = '離';
    accepted.textContent = '到';

    recID.textContent = ("欲訪住戶 : "+doc.data().recID);
    
    actual_arrival_time.textContent = ("實際抵達時間:" + actual_arrival_Date);
    actual_leave_time.textContent = ("實際離開時間:" + actual_leave_Date);
    expected_arrive_time.textContent = ("預計抵達時間:" +expected_arrive_Date);
    expected_leave_time.textContent = ("預計離開時間:"+ expected_leave_Date);

    

    li.appendChild(visitor_name);
    li.appendChild(recID);
    li.appendChild(phone);
  
    li.appendChild(expected_arrive_time);
    li.appendChild(expected_leave_time);
    li.appendChild(visitor_status);

     //白痴判斷

    if(doc.data().visitor_status == '已到達'){

        li.appendChild(actual_arrival_time);

    }else if(doc.data().visitor_status =="已離開"){

        li.appendChild(actual_arrival_time);
        li.appendChild(actual_leave_time);

    }
    li.appendChild(accepted);
    li.appendChild(lv);
   
    li.appendChild(cross);
    visitorList.appendChild(li);

   



    //ART

    lv.addEventListener('click', (e) => {
        if (doc.data().visitor_status == "已離開") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "訪客已離開了嗎?",
                text: "點確定後更新為已離開!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('Visitor').doc(id).update({
                        visitor_status: "已離開",
                        actual_leave_time: firebase.firestore.FieldValue.serverTimestamp(),
                    })
                    swal("您已成功更新資料", {
                        icon: "success",
                    });
                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 1500);
            });

        }
    })



    accepted.addEventListener('click', (e) => {
        if (doc.data().visitor_status == "已到達") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "訪客已抵達了嗎?",
                text: "點確定後更新為已抵達!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('Visitor').doc(id).update({
                        visitor_status: "已到達",
                        actual_arrival_time: firebase.firestore.FieldValue.serverTimestamp(),
                    })
                    swal("您已成功更新資料", {
                        icon: "success",
                    });
                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 1500);
            });

        }
    })

    // deleting data
    cross.addEventListener('click', (e) => {
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('Visitor').doc(id).delete();
                    swal("Poof! Your imaginary file has been deleted!", {
                        icon: "success",
                    });
                } else {
                    swal("Your imaginary file is safe!");
                }
            });

    });


/*
     up.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        location.href = "EditVisitor.html";
})

*/

}

// getting data
//Queries:  db.collection('UsersTest').where('?','==','?').orderBy('name').get()
// set up index inside the firebase to Enable 


//real-time listener to listen changes

if (key == null) {
db.collection('Visitor').orderBy('createdAt', 'desc').onSnapshot(snapshot => {

    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if(change.type == 'added'){
            renderVser(change.doc);
        } else if (change.type == 'removed'){
            let li =visitorList.querySelector('[data-id=' + change.doc.id + ']');
            visitorList.removeChild(li);
        }
    });
     sessionStorage.removeItem('key');
});

}else if(choice == 1){
db.collection('Visitor').where("recID","==",key).onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if(change.type == 'added'){
            renderVser(change.doc);
        } else if (change.type == 'removed'){
            let li =visitorList.querySelector('[data-id=' + change.doc.id + ']');
            visitorList.removeChild(li);
        }
    });
     sessionStorage.removeItem('key');
});
}

// saving data 

/*
form.addEventListener('submit', (e) => {
    
    e.preventDefault();  //not to refresh page
    db.collection('Visitor').add({
        user_name: form.user_name.value,
   
    });
    form.user_name.value = '';
    
});
*/

searchBtn.addEventListener('click', (e) => {
    var db = firebase.firestore();
    var ref = db.collection('Visitor').doc(searchtext.value);
    ref.get().then(doc => {
        console.log(doc.data());
    });
    sessionStorage.setItem("key", searchtext.value);
    sessionStorage.setItem("choice", 1);
    location.href = "VLTest.html";
});