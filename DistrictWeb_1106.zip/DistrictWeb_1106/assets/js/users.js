const List = document.querySelector('#chat');
const List2 = document.querySelector('#chat-area');

const db = firebase.firestore();
const db2 = firebase.firestore();


//var chatdiv = document.createElement("chat-outgoing");

const typing = document.getElementById('typing');


const nametop2 = document.querySelector('#chatheader');
const nametop3 = document.querySelector('#chatheader2');
// const AdminId = sessionStorage.getItem('AdminId');
const Adminid02 = sessionStorage.getItem('AdminId');
// console.log(AdminId);
// var docRef = database.collection("admin").doc(AdminId);

var AdminName;


var docRef = database.collection("admin").doc(AdminId);

docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        AdminName = doc.data().name;
        console.log(AdminName);

        nametop2.querySelector('#adminname').innerHTML = AdminName;
        nametop3.querySelector('#adminname').innerHTML = AdminName;
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function chatCate(doc) {
    let li = document.createElement('li');
    let img = document.createElement('img');
    let rec = document.createElement('span');

    li.setAttribute('data-id', doc.id);
    img.textContent = "";
    rec.textContent = doc.id;

    List.appendChild(li);
    li.appendChild(img);
    li.appendChild(rec);

    rec.addEventListener('click', (e) => {

        let id = e.target.parentElement.getAttribute('data-id');


        function chatarea(doc) {


            let li = document.createElement('li');
            let text = document.createElement('p');
            let senderName = document.createElement('span');



            li.setAttribute('data-id', doc.id);
            text.textContent = (doc.data().text);
            senderName.textContent = doc.data().senderName;


            List2.appendChild(li);
            li.appendChild(senderName);
            li.appendChild(text);

        }


        db2.collection('chat').doc(id).collection('message').where("senderId", "==", 'zLavX4oqINWPXdrGZF6MV4pRPOo1').onSnapshot(snapshot => {
            let changes = snapshot.docChanges();
            changes.forEach(change => {
                console.log(change.doc.data());
                if (change.type == 'added') {

                    chatarea(change.doc);

                } else if (change.type == 'removed') {
                    let li = List2.querySelector('[data-id=' + change.doc.id + ']');
                    List2.removeChild(li);
                }

            });
            showPopup();
        });

        //docRef.get().then((doc) => {
        // AdminName = doc.data().name;
        // console.log(AdminName);



        //})

    })
}

db.collection('chat').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        console.log(change.doc.data());
        if (change.type == 'added') {

            chatCate(change.doc);

        } else if (change.type == 'removed') {
            let li = List.querySelector('[data-id=' + change.doc.id + ']');
            List.removeChild(li);
        }
    });
});


var baseText = null;

function showPopup() {

    var popUp = document.getElementById("popupcontent");

    popUp.style.bottom = "0px";

    popUp.style.right = "300px";

    popUp.style.width = "500px";

    popUp.style.height = "700px";

    if (baseText == null) baseText = popUp.innerHTML;

    popUp.innerHTML = baseText + "<div id=\"statusbar\"><button onclick=\"hidePopup;\"><button></div>";
    popUp.innerHTML = baseText + "<div id=\"statusbar\"><button onclick=\"testChat;\"><button></div>";


    var sbar = document.getElementById("statusbar");

    sbar.style.marginTop = (parseInt()) + "px";


    popUp.style.visibility = "visible";

}

function hidePopup() {

    var popUp = document.getElementById("popupcontent");

    popUp.style.visibility = "hidden";

}

function testChat(){

db2.collection("chat").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {

    db2.collection("chat").doc(doc.id).collection('message').add({

         dateSent: firebase.firestore.FieldValue.serverTimestamp(),
                rec: "admin",
                senderId: "zLavX4oqINWPXdrGZF6MV4pRPOo1",
                senderName: AdminName,
                sending:'Kni5JPqnTbT7qRjqkEKnsWsE4x92',
                text: "recr",
                
                 //抓下來的東西要用時間排序
                //text 現在是寫死的 想辦法讀到值
        })

  });
});

}