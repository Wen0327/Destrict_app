//輸出list
const fMList = document.querySelector('#fM-list');
const fMmoneyList = document.querySelector('#fM-moneylist');
const key = sessionStorage.getItem('key');
console.log(key);



function fMrenderVser(doc){
	let li = document.createElement('li');
	let recID = document.createElement('span');
	let 付款方式 = document.createElement('span');
	let 繳費期別 = document.createElement('span');
	let 應付帳款 = document.createElement('span');
	let 實付帳款 = document.createElement('span');
	

//get Unique ID
    li.setAttribute('data-id', doc.id);
   
    recID.textContent = (doc.data().recID);
    付款方式.textContent = (doc.data().付款方式);
    繳費期別.textContent = (doc.data().繳費期別);
    應付帳款.textContent =(doc.data().應付帳款);
    實付帳款.textContent =(doc.data().實付帳款);


    li.appendChild(recID);
    li.appendChild(繳費期別);
    li.appendChild(付款方式);
    li.appendChild(應付帳款);
    li.appendChild(實付帳款);
    console.log(recID);

    繳費列表.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        fmprogress.style.marginLeft = '160px'
        期別列表.style.color = '	#404040';
        繳費列表.style.color = '	#127436';
        fMmoneyList.appendChild(li);
        $('#fM-list').empty();

        名稱.remove();
        建立時間.remove();
        三角A.remove();
        三角A上.remove();
        三角A下.remove();
        啟用狀態.remove();
        三角B.remove();
        三角B上.remove();
        三角B下.remove();

        refm_1.style.display = 'inline';
        refm_1.style.color ='black';
        refm_2.style.display = 'inline';
        refm_2.style.color ='black';
        refm_3.style.display = 'inline';
        refm_3.style.color ='black';
        refm_4.style.display = 'inline';
        refm_4.style.color ='black';
        refm_5.style.display = 'inline';
        refm_5.style.color ='black';   

    })
    
}


function renderVser(doc){
	let li      = document.createElement('li');
	let 期別名稱 = document.createElement('span');
	let time    = document.createElement('span');
	let 狀態     = document.createElement('span');
    let 啟用     = document.createElement("button");
    let 結束     = document.createElement("button");
    let 編輯     = document.createElement("button");

    let li2     = document.createElement('li2');
    let 點擊查看 = document.createElement('span');
    let 點擊關閉 = document.createElement('span');
    let 期別備註 = document.createElement('span');

    let 啟用時間 = document.createElement('span');
    let 繳費期限 = document.createElement('span');


    var readableDate = doc.data().createdAt.toDate().toLocaleDateString();
    var 啟用日期      = doc.data().啟用時間.toDate().toLocaleDateString();
    var 結束日期      = doc.data().結束時間.toDate().toLocaleDateString();

    //var 啟用A = doc.data().啟用時間;

    //
    var 啟用A = new Date();
    var second = 啟用A.getTime();
    var 期別天數2 =doc.data().期別天數;
    var datetime = 啟用A.setTime(second + 1000 * 60 * 60 * 24 * 期別天數2);

    console.log(datetime);
    let nt = moment().valueOf();

    console.log(nt);

    

    if(datetime < nt ){

         db.collection('feeManage').doc(doc.id).update({
              狀態: "關閉中",
              st:'2',
              結束時間: firebase.firestore.FieldValue.serverTimestamp(),
     })

    }
////

   
      

//get Unique ID
    li.setAttribute('data-id', doc.id);
    li2.setAttribute('data-id', doc.id);
    期別名稱.textContent = (doc.data().期別名稱);
    time.textContent = (readableDate);
    狀態.textContent = (doc.data().狀態);
    啟用.textContent = '啟用';
    結束.textContent = '關閉';
    編輯.textContent ='編輯';
    點擊查看.textContent = '查看細項';
    點擊關閉.textContent ='點擊關閉';
    期別備註.textContent = (doc.data().期別備註);
    繳費期限.textContent = (結束日期);
    
    li.appendChild(期別名稱);
    li.appendChild(time);
    li.appendChild(狀態);
    li.appendChild(點擊查看);

    li.appendChild(啟用);
    li.appendChild(編輯);
    
    fMList.appendChild(li);
    fMList.appendChild(li2);


    if(doc.data().狀態 =="已啟用" ){

    	狀態.style.color = 'red';
    	li.replaceChild(結束,啟用);

    }else if(doc.data().狀態 =="關閉中"){

    	狀態.style.color = 'black';
    	li.replaceChild(結束,啟用);
    	li.replaceChild(啟用,結束);

    }

    啟用.addEventListener('click', (e) => {
        if (doc.data().狀態 == "已啟用") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要啟用了嗎?",
                text: "點確定後更新為已啟用!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('feeManage').doc(id).update({
                        狀態: "已啟用",
                        st:"1",
                        啟用時間: firebase.firestore.FieldValue.serverTimestamp(),
                    })

                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 1500);
            });    
        }
      
    })

    結束.addEventListener('click', (e) => {
        if (doc.data().狀態 == "關閉中") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要關閉了嗎?",
                text: "點確定後更新為已關閉!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    db.collection('feeManage').doc(id).update({
                        狀態: "關閉中",
                        st:'1',
                        結束時間: firebase.firestore.FieldValue.serverTimestamp(),
                    })

                } else {
                    swal("狀態並未更動!");
                }
                setTimeout(function(){window.location.reload();}, 1500); //1.5秒後自動re
            });    
        }
      
    })

    點擊查看.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        li2.appendChild(期別備註);
        li.replaceChild(點擊關閉, 點擊查看);      
    })

    點擊關閉.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        li2.removeChild(期別備註);
        li.replaceChild(點擊查看, 點擊關閉);
       
    })

    /////修改

    var f4 = document.getElementById("f4");
    var modifyCancel = document.getElementById("modifyCancel");
    var modify_Community_Name = document.getElementById("modify_Community_Name");
    var modify_Community_Address = document.getElementById("modify_Community_Address");
    var modify_Period_Name = document.getElementById("modify_Period_Name");
    var modify_Period_Remarks = document.getElementById("modify_Period_Remarks");

    modifyCancel.onclick = function(){

	document.querySelector('.bg-modal2').style.display = 'none';
	document.getElementById("modify_Community_Name").value = "";
	document.getElementById("modify_Community_Name").innerHTML = "";
	document.getElementById("Community_Address").value = "";
	document.getElementById("Community_Address").innerHTML = "";
	document.getElementById("modify_Period_Name").value = "";
	document.getElementById("modify_Period_Name").innerHTML = "";
	document.getElementById("modify_Period_Remarks").value = "";
	document.getElementById("modify_Period_Remarks").innerHTML = "";
	document.documentElement.style.overflowY = 'scroll'; 
	
}

const modifySubmit = document.getElementById("modifySubmit");

///修改

編輯.addEventListener('click',
	function(e){
		location.href='#';
		let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
		document.body.scrollTop = '0';
		document.querySelector('.bg-modal2').style.display = 'flex';
		document.documentElement.style.overflowY = 'hidden'; 

const database3 = firebase.firestore();
const usersCollection = database3.collection('feeManage');
const doc_key= sessionStorage.getItem('key');
console.log(doc_key);



const docRef = database3.collection("feeManage").doc(doc_key);
var 社區名稱2;
var 社區地址2;
var 期別名稱2;
var 期別備註2;

 modifySubmit.addEventListener('click', e => {

  e.preventDefault();
    const ID = usersCollection.doc(doc_key).update({

    社區名稱: modify_Community_Name.value,
    社區地址: modify_Community_Address.value,
    期別名稱: modify_Period_Name.value,
    期別備註: modify_Period_Remarks.value,
 
  })
  .then(()=>{ 
    console.log('Data has been saved successfully !');
    //鎖定
	document.documentElement.style.overflowY = 'scroll'; 
	setTimeout(function(){window.location.reload();}, 1000);


})
    swal({
  title: "Good job!",
  text: "You clicked the button!",
  icon: "success",
  button: "Send successfully!",
})
  .catch(error => {
    console.error(error)
  });
});

 docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());

        社區名稱2 = doc.data().社區名稱;  
        社區地址2 = doc.data().社區地址;        
        期別名稱2 = doc.data().期別名稱;      
        期別備註2 = doc.data().期別備註;
       
        var modify_Community_Name =  document.getElementById('modify_Community_Name').value += 社區名稱2;
        var modify_Community_Address = document.getElementById('modify_Community_Address').value += 社區地址2;
        var modify_Period_Name = document.getElementById('modify_Period_Name').value += 期別名稱2;
        var modify_Period_Remarks = document.getElementById('modify_Period_Remarks').value += 期別備註2;
              
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);

});

 });


 期別列表.addEventListener('click', (e) => {

        let id = e.target.parentElement.getAttribute('data-id');

        sessionStorage.setItem("key", id);
        期別列表.style.color = '#127436';
        繳費列表.style.color = '#404040';
        fmprogress.style.marginLeft = '10px'

         $('#fM-moneylist').empty();
         setTimeout(function(){window.location.reload();}, 200);
       
})
/////


}

//real-time listener to listen changes
$('#fM-moneylist').empty();
db.collection('feeManage').orderBy('createdAt','desc').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if(change.type == 'added'){
            renderVser(change.doc);
        } else if (change.type == 'removed'){
            let li =fMList.querySelector('[data-id=' + change.doc.id + ']');
            fMList.removeChild(li);
        }

    })
})


//抓取2層collection

db.collection("users").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        
        console.log(doc.id);

    db.collection('users').doc(doc.id).collection('feeManage').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if(change.type == 'added'){
            fMrenderVser(change.doc);
        } else if (change.type == 'removed'){
            let li =fMmoneyList.querySelector('[data-id=' + change.doc.id + ']');
            fMmoneyList.removeChild(li);
        }

    })
})

    });
});


//彈出式表單

var f1 = document.getElementById("f1");
var f2 = document.getElementById("f2");
var f3 = document.getElementById("f3");
var Next1 = document.getElementById("Next1");
var Back1 = document.getElementById("Back1");
var Next2 = document.getElementById("Next2");
var Back2 = document.getElementById("Back2");
var Cancel = document.getElementById("Cancel");
var progress = document.getElementById("progress");

var Community_Name = document.getElementById("Community_Name");
var Community_Address = document.getElementById("Community_Address");
var Period_Name = document.getElementById("Period_Name");
var Period_Day = document.getElementById("Period_Name");
var Period_Remarks = document.getElementById("Period_Remarks");
var Sqm_Money = document.getElementById("Sqm_Money");
var C_Money = document.getElementById("C_money");
var buttonfM = document.getElementById("buttonfM");



Next1.onclick = function(){

	f1.style.left = "-450px";
	f2.style.left = "40px";
	progress.style.width = "240px";
}
Back1.onclick = function(){

	f1.style.left = "40px";
	f2.style.left = "450px";
	progress.style.width = "120px";
}
Next2.onclick = function(){

	f2.style.left = "-450px";
	f3.style.left = "40px";
	progress.style.width = "360px";
}
Back2.onclick = function(){

	f2.style.left = "40px";
	f3.style.left = "450px";
	progress.style.width = "240px";
}

Cancel.onclick = function(){

	document.querySelector('.bg-modal').style.display = 'none';
	document.getElementById("Community_Name").value = "";
	document.getElementById("Community_Name").innerHTML = "";
	document.getElementById("Community_Address").value = "";
	document.getElementById("Community_Address").innerHTML = "";
	document.getElementById("Period_Name").value = "";
	document.getElementById("Period_Name").innerHTML = "";
	document.getElementById("Period_Remarks").value = "";
	document.getElementById("Period_Remarks").innerHTML = "";
	document.getElementById("Sqm_Money").value = "";
	document.getElementById("Sqm_Money").innerHTML = "";
	document.getElementById("C_Money").value = "";
	document.getElementById("C_Money").innerHTML = "";
	document.documentElement.style.overflowY = 'scroll'; 
	
}

//open form
document.getElementById('buttonfM').addEventListener('click',
	function(){
		document.querySelector('.bg-modal').style.display = 'flex';
		document.documentElement.style.overflowY = 'hidden'; 

	});


//三角箭頭 //排序

$(function () {
    $(".arrUp").on("click", function () {
      
      $(this).css("border-bottom-color", "#b2b2b2");
      $(".arrDown").css("border-top-color", "#ccc");
      $('#fM-list').empty();
      
       db.collection('feeManage').orderBy('st').onSnapshot(snapshot => {
        let changes = snapshot.docChanges();
        changes.forEach(change => {
            if (change.type == 'added') {
                renderVser(change.doc);
            } else if (change.type == 'removed') {
                let li = SuggestionList.querySelector('[data-id=' + change.doc.id + ']');
                SuggestionList.removeChild(li);
            }
        });
    });      
    });


    $(".arrDown").on("click", function () {

      $(this).css("border-top-color", "#b2b2b2")
      $(".arrUp").css("border-bottom-color", "#ccc");
      $('#fM-list').empty();
      
       db.collection('feeManage').orderBy('st','desc').onSnapshot(snapshot => {
        let changes = snapshot.docChanges();
        changes.forEach(change => {
            if (change.type == 'added') {
                renderVser(change.doc);
            } else if (change.type == 'removed') {
                let li = SuggestionList.querySelector('[data-id=' + change.doc.id + ']');
                SuggestionList.removeChild(li);
            }
        });
    }); 
    })
  })

$(function () {
    $(".arrUp2").on("click", function () {
      $('#fM-list').empty();
      $(this).css("border-bottom-color", "#b2b2b2");
      $(".arrDown").css("border-top-color", "#ccc");

      
       db.collection('feeManage').orderBy('createdAt').onSnapshot(snapshot => {
        let changes = snapshot.docChanges();
        changes.forEach(change => {
            if (change.type == 'added') {
                renderVser(change.doc);
            } else if (change.type == 'removed') {
                let li = SuggestionList.querySelector('[data-id=' + change.doc.id + ']');
                SuggestionList.removeChild(li);
            }
        });
    });
    });
    $(".arrDown2").on("click", function () {
      $('#fM-list').empty();
      $(this).css("border-top-color", "#b2b2b2")
      $(".arrUp").css("border-bottom-color", "#ccc");

      
       db.collection('feeManage').orderBy('createdAt','desc').onSnapshot(snapshot => {
        let changes = snapshot.docChanges();
        changes.forEach(change => {
            if (change.type == 'added') {
                renderVser(change.doc);
            } else if (change.type == 'removed') {
                let li = SuggestionList.querySelector('[data-id=' + change.doc.id + ']');
                SuggestionList.removeChild(li);
            }
        });
    }); 
    })
  })


//Add 新增

const 社區名稱 = document.getElementById('Community_Name');
const 社區地址 = document.getElementById('Community_Address');
const 期別名稱 = document.getElementById('Period_Name');
const 期別天數 = document.getElementById('Period_Day');
const 期別備註 = document.getElementById('Period_Remarks');
const 每坪台幣 = document.getElementById('Sqm_Money');
const 每車位台幣 = document.getElementById('C_Money');

const Submit = document.getElementById("Submit");
console.log(AdminId);
const database2 = firebase.firestore();
const usersCollection = database2.collection('feeManage');
var docRef = database2.collection("admin").doc(AdminId);


docRef.get().then((doc) => {
    
    if (doc.exists) {
        console.log("Document data:", doc.data());
        AdminName = doc.data().name;
        console.log(AdminName);

        Submit.addEventListener('click', e => {
            let id = 期別名稱.value;
            console.log(id);
            database2.collection("feeManage").get().then((querySnapshot) => {
                querySnapshot.forEach((doc) => {
                    if (id === doc.id) {
                        swal("同一資料已重複輸入");
                    } else if (社區名稱.value === null || 社區名稱.value === '' ||  社區地址.value === null || 社區地址.value === '' || 期別名稱.value === null || 期別名稱.value === ''|| 每坪台幣.value === null || 每坪台幣.value === ''|| 每車位台幣.value === null || 每車位台幣.value === '') {
                        swal("請輸入所有資料");
                    } else {
                        e.preventDefault();
                        const ID = usersCollection.doc(id).set({
                                社區名稱: 社區名稱.value,
                                社區地址: 社區地址.value,
                                期別名稱: 期別名稱.value,
                                期別天數: parseInt(期別天數.value),
                                期別備註: 期別備註.value,
                                每坪台幣: parseInt(每坪台幣.value),
                                每車位台幣: parseInt(每車位台幣.value),
                                狀態: "關閉中",
                                st:"1",
                                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                                createdBy: AdminName,
                                結束時間: firebase.firestore.FieldValue.serverTimestamp() ,
                                啟用時間: firebase.firestore.FieldValue.serverTimestamp(),

                            })
                            .then(() => {
                                console.log('Data has been saved successfully !')
                                document.querySelector('.bg-modal').style.display = 'none';
	                            document.getElementById("Community_Name").value = "";
	                            document.getElementById("Community_Name").innerHTML = "";
	                            document.getElementById("Community_Address").value = "";
	                            document.getElementById("Community_Address").innerHTML = "";
	                            document.getElementById("Period_Name").value = "";
	                            document.getElementById("Period_Name").innerHTML = "";
	                            document.getElementById("Period_Remarks").value = "";
	                            document.getElementById("Period_Remarks").innerHTML = "";
	                            document.getElementById("Sqm_Money").value = "";
	                            document.getElementById("Sqm_Money").innerHTML = "";
	                            document.getElementById("C_Money").value = "";
	                            document.getElementById("C_Money").innerHTML = "";
	                            document.documentElement.style.overflowY = 'scroll'; 
	                            setTimeout(function(){window.location.reload();}, 1000);

                            })
                            swal({
                                title: "Good job!",
                                text: "You clicked the button!",
                                icon: "success",
                                button: "Send successfully!",
                            })
                            .catch(error => {
                                console.error(error)
                            });
                    }
                });
            });    
        });
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

//轉換頁面

var 期別列表 = document.getElementById('fm_list');
var 繳費列表 = document.getElementById('fm_monylist');
var link_top = document.getElementById('link-top');

期別列表.style.color = '#127436';

//replace

var 名稱 = document.getElementById('fm_1');
var 建立時間 = document.getElementById('fm_2');

var 三角A = document.getElementById('fm_3');
var 三角A上 = document.getElementById('fm_4');
var 三角A下 = document.getElementById('fm_5');
var 啟用狀態 = document.getElementById('fm_6');
var 三角B = document.getElementById('fm_7');
var 三角B上 = document.getElementById('fm_8');
var 三角B下 = document.getElementById('fm_9');

var 戶別 = document.getElementById('refm_1');
var 期別 = document.getElementById('refm_2');
var 付款方式 = document.getElementById('refm_3');
var 應付帳款 = document.getElementById('refm_4');
var 實付帳款 = document.getElementById('refm_5');
