<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/8.5.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.5.0/firebase-firestore.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
<script src="https://www.gstatic.com/firebasejs/8.5.0/firebase-analytics.js"></script>

<script>
  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  var firebaseConfig = {
    apiKey: "AIzaSyB5rthlgOBnN1EshXPBoAEkQjWgETHxCnE",
    authDomain: "login-a22c0.firebaseapp.com",
    databaseURL: "https://login-a22c0-default-rtdb.firebaseio.com",
    projectId: "login-a22c0",
    storageBucket: "login-a22c0.appspot.com",
    messagingSenderId: "817187672807",
    appId: "1:817187672807:web:6c97db3b762058159ec842",
    measurementId: "G-EXCE01SZ3E"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
</script>

