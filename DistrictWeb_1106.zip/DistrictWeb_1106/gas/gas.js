
const moonLanding = new Date();
console.log(moonLanding.getMonth() + 1);


const currentDateTime = moment().format('M');
console.log(currentDateTime);

const NowDateTime = moment().format('MM/DD/YYYY');
console.log(NowDateTime);

an_db.collection("utilities").where("month", "==", currentDateTime)
    .get()
    .then(querySnapshot => {
        querySnapshot.forEach(doc => {
            let data = doc.data();
            let row = `<tr>
                            <td>${data.recID}</td>
                            <td>${data.gree}</td>
                            <td>${data.time}</td>
                      </tr>`;
            let table = document.getElementById('myTable')
            table.innerHTML += row
        })
    })
    .catch(err => {
        console.log(`Error: ${err}`)
    });