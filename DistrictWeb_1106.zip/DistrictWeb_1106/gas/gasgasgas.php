
<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <meta http-equiv=”Content-Type” content=”text/html; charset=utf-8″>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <title>設備管理</title>

    <!-- Bootstrap core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 
    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="../assets/css/fontawesome.css">
    <link rel="stylesheet" href="../assets/css/templatemo-style.css">
    <link rel="stylesheet" href="../assets/css/owl.css">

    <!-- chatbox -->
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="../assets/css/chatbox.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
   
    

    <script src="https://www.gstatic.com/firebasejs/8.5.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.5.0/firebase-firestore.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script src="../vendor/daterangepicker/moment.min.js"></script>


</head>

<!--彈出式新增表單-->
<div class="bg-modal">  
       <div class="modal-content">

        
       </div>
</div>


<body class="is-preload">

    <!-- Wrapper -->
    <div id="wrapper">

        <!-- Main -->
        <div id="main">
            <div class="inner">

                <!-- Header -->
                <header id="header">
                    <div class="logo">
                        <a href="../index.html">社區管理系統</a>
                        <a id="adminname"> </a>
                    </div>
                </header>

                <!-- Banner 
                <section class="main-banner">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="banner-content">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="banner-caption">
                                                <h4>你好<em>早安</em> 晚安</h4>
                                                <span>副標題</span>
                                                <p>內容 <strong>主題</strong> 內容 <strong>AA</strong>內容</p>
                                                <div class="primary-button">
                                                    <a href="#">想幹嘛</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section> -->

                <!-- Services -->
                <section class="services">
                    <h2>住戶瓦斯度數 <?php echo date("m");?>月</h2>

        <div class="table-wrapper">
            <table class="fl-table">
                <thead>
                    <tr>
                        <th>住戶</th>
                        <th>瓦斯度數</th>
                        <th>更新時間</th>
                  </tr>
             </thead>
             <tbody id="myTable">
              </tbody>
            </table>
        </div>

                </section>

                </div>
            </div>

            <!-- Sidebar -->
            <div id="sidebar">

                <div class="inner">

                    <!-- Search Box -->
                    <section id="search" class="alt">
                        <form method="get" action="#">
                            <input type="text" name="search" id="search" placeholder="搜尋..." />
                        </form>
                    </section>

                    <!-- Menu -->
                    <nav id="menu">
                        <ul>
                            <li><a href="../index.html">首頁</a></li>
                            <li><a href="../indexLog.html">重新登入</a></li>
                            <li><a href="">連結到一個地址</a></li>
                            <li>
                                <span class="opener">管理端功能</span>
                                <ul>
                                   <li><a href="../index.html#co_info">社區資訊</a></li>
                                <li><a href="../index.html#Life_management">生活管理</a></li>
                                <li><a href="../index.html#co_inter">社區互動</a></li>
                                </ul>
                            </li>
                            <li>
                                <span class="opener">下拉式第二</span>
                                <ul>
                                    <li><a href="#">第一個選項</a></li>
                                    <li><a href="#">第二個選項</a></li>
                                    <li><a href="#">第三個選項</a></li>
                                </ul>
                            </li>
                            <li><a href="https://www.google.com">不知道幹嘛去google</a></li>
                        </ul>
                    </nav>

                    <!-- Featured Posts -->
                    <div class="featured-posts">
                        <div class="heading">
                            <h2>滑動圖案餒</h2>
                        </div>
                        <div class="owl-carousel owl-theme">
                            <a href="#">
                                <div class="featured-item">
                                    <img src="../assets/images/featured_post_01.jpg" alt="featured one">
                                    <p>安安.</p>
                                </div>
                            </a>
                            <a href="#">
                                <div class="featured-item">
                                    <img src="../assets/images/featured_post_01.jpg" alt="featured two">
                                    <p>安安.</p>
                                </div>
                            </a>
                            <a href="#">
                                <div class="featured-item">
                                    <img src="../assets/images/featured_post_01.jpg" alt="featured three">
                                    <p>安安.</p>
                                </div>
                            </a>
                        </div>
                    </div>

                    <!-- Footer -->
                    <footer id="footer">
                        <p class="copyright">這裡沒有東西
                            <br>Designed by <a rel="nofollow">QQPR</a></p>
                    </footer>

                </div>
            </div>

            <div class="chat">

        <input class="inputchat" type="checkbox" id="click">
        <label class="labelchat" for="click">
            <i class="fab fa-facebook-messenger"></i>
            <i class="fas fa-times"></i>
        </label>
        <div class="wrapperchat">

            <section class="users">
                <header id="chatheader">
                    <div class="content">
                        <img src="../server-icon.png" alt="">
                        <div class="details">
                            <a id="adminname"> </a>
                            <p>action now</p>

                        </div>
                </header>
                <div class="search">
                    <span class="text">Select an user to start chat</span>
                    <input type="text" placeholder="Enter name to search...">
                    <button><i class="fas fa-search"></i></button>
                </div>


                <ul id="chat"></ul>



                <div class="wrapperchatarea" id="popupcontent">

                    <section class="chat-area">
                        <header id="chatheader2">
                            <a href="#" class="back-icon" onclick="hidePopup()"><i class="fas fa-arrow-left"></i></a>
                            <img src="../server-icon.png" alt="">
                            <div class="details" style="margin-top:20px;">
                                <a id="adminname"> </a>
                                <p>action now</p>

                            </div>
                        </header>

                        <div class="chat-box">
                            <div class="chat outgoing" id="chat-outgoing">
                                <div class="details">
                                    <ul id="chat-area"></ul>
                                </div>
                            </div>
                        </div>
                        <form action="#" class="typing-area">
                            <input id="typing" type="text" placeholder="Type a message here...">
                            <button id="typingBtn"><i class="fab fa-telegram-plane"></i></button>
                        </form>
                    </section>
                </div>



            </section>

            </div>

        </div>

        </div>

        <!-- Scripts -->
        <!-- The core Firebase JS SDK is always required and must be listed first -->
        <script src="https://www.gstatic.com/firebasejs/7.3.0/firebase-app.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.3.0/firebase-firestore.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.3.0/firebase-auth.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.3.0/firebase-storage.js"></script>
        <!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->


        <script>
            // Your web app's Firebase configuration
            // For Firebase JS SDK v7.20.0 and later, measurementId is optional
            var firebaseConfig = {
                apiKey: "AIzaSyB5rthlgOBnN1EshXPBoAEkQjWgETHxCnE",
                authDomain: "login-a22c0.firebaseapp.com",
                databaseURL: "https://login-a22c0-default-rtdb.firebaseio.com",
                projectId: "login-a22c0",
                storageBucket: "login-a22c0.appspot.com",
                messagingSenderId: "817187672807",
                appId: "1:817187672807:web:dfef55bfe6284d699ec842",
                measurementId: "G-RFE15D1SLK"
            };

            // Initialize Firebase
            firebase.initializeApp(firebaseConfig);

            const an_db = firebase.firestore();


        </script>
        <!-- Bootstrap core JavaScript -->
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../assets/js/browser.min.js"></script>
        <script src="../assets/js/breakpoints.min.js"></script>
        <script src="../assets/js/transition.js"></script>
        <script src="../assets/js/owl-carousel.js"></script>
        <script src="../assets/js/custom.js"></script>
        <script src="../assets/js/name.js"></script>
        <link rel=stylesheet type="text/css" href="gas.css">

        <script src="../assets/js/users.js"></script>

        <script src="gas.js"></script>
        
        

</body>


</body>

</html>