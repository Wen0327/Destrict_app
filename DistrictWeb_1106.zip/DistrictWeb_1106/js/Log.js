const auth = firebase.auth();

const logbtn = document.getElementById('login');


const loginForm = document.querySelector('#formlog');
logbtn.addEventListener('click', (e) => {
    e.preventDefault();

    // get user info
    const email = loginForm['email'].value;
    const password = loginForm['pass'].value;

    // log the user in
    auth.signInWithEmailAndPassword(email, password).then((cred) => {
        // close the signup modal & reset form
        //const modal = document.querySelector('#modal-login');
        // M.Modal.getInstance(modal).close();
        loginForm.reset();
        loginForm.querySelector('#error').innerHTML = '';
        console.log("suc");
        if (email === "adminpony@gmail.com") {
            sessionStorage.setItem("AdminId", "rAoFB11NZvVxRu3PNWhOfAr7pnH2");
            sessionStorage.setItem("AdminName", "AdminPony");

        } else if (email === "adminpipe@gmail.com") {
            sessionStorage.setItem("AdminId", "zLavX4oqINWPXdrGZF6MV4pRPOo1");
            sessionStorage.setItem("AdminName", "AdminPipe");
        } else if (email === "adminwen@gmail.com") {
            sessionStorage.setItem("AdminId", "D4Ntt2NI8fdlX31hWDoqz4s75au1");
            sessionStorage.setItem("AdminName", "AdminWen");
        } else if (email === "admincat@gmail.com"){
            sessionStorage.setItem("AdminId", "IqiJu3EdrYgptnpKB7ck9rWMLUl2");
            sessionStorage.setItem("AdminName", "AdminCat");
        } else {
			 sessionStorage.setItem("AdminId", "bOAscXRLZDV1S1Hn97dsb8eHS4c2");
            sessionStorage.setItem("AdminName", "yw2004");
		}
        swal({
                title: "成功登入",
                text: "點擊OK開始使用社區管理系統",
                icon: "success",
                buttons: true,

            })
            .then((willDelete) => {
                if (willDelete) {
                    location.href = "index.html";
                    swal("Poof! Your imaginary file has been deleted!", {
                        icon: "success",
                    });
                } else {
                    swal("已取消登入!");
                }
            });

    }).catch(err => {
        loginForm.querySelector('#error').innerHTML = "帳號密碼輸入錯誤";
        console.log("bad");
    });

});

function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}