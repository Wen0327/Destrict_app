const building = document.getElementById('building');
const names = document.getElementById('names');
const floor = document.getElementById('floor');
const door = document.getElementById('door');
const addBtn = document.getElementById('addBtn');
const backBtn = document.getElementById('backBtn');
const accept = document.getElementById('accept');

const usersCollection = an_db.collection('mail pack');

console.log(AdminId);
var docRef = an_db.collection("admin").doc(AdminId);

var dt = new Date();
var second = dt.getTime();
var datetime = dt.setTime(second + 1000 * 60 * 60 * 24 * 7);
const endtime = new Date(datetime);

console.log(endtime);

docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        AdminName = doc.data().name;
        console.log(AdminName);

        addBtn.addEventListener('click', e => {
            let id = building.value + '-' + floor.value + '-' + door.value;
            if (building.value === null || building.value === '' || names.value === null || names.value === '' || floor.value === null || floor.value === '' || door.value === null || door.value === '') {
                swal("請輸入所有資料");
            } else {
                e.preventDefault();
                console.log(id);
                an_db.collection('users').where("recID", "==", id).onSnapshot(snapshot => {
                    let changes = snapshot.docChanges();
                    changes.forEach(change => {
                        console.log(change.doc.data());
                        var usersdoc = change.doc.id;
                        const ID = usersCollection.doc().set({
                                names: names.value,
                                building: building.value,
                                floor: floor.value,
                                door: door.value,
                                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                                createdBy: AdminName,
                                endtime: endtime,
                                endtimesecond: datetime,
                                Usersdoc: usersdoc,
                                ID: id,
                                accept: "未領收",
                                modifytime: firebase.firestore.FieldValue.serverTimestamp(),
                            })
                            .then(() => {
                                console.log('Data has been saved successfully !')
                            })
                        swal({
                                title: "成功建立資料!",
                                text: "您已成功建立資料!",
                                icon: "success",
                                button: "Send successfully!",
                            })
                            .catch(error => {
                                console.error(error)
                            });
                    });
                });
            }
        });

    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});


backBtn.addEventListener('click', e => {
    location.href = "package.html";
});