const package_List = document.querySelector('#mail_art');
const addBtn = document.getElementById('addBtn');
const searchBtn = document.getElementById('searchBtn');
const endBtn = document.getElementById('endBtn');
const form = document.querySelector('#form');


const searchtext = document.getElementById('searchtext');
console.log(AdminId);
const key = sessionStorage.getItem('key');
console.log(key);
const choice = sessionStorage.getItem('choice');
console.log(choice);
const etime = sessionStorage.getItem('etime');
console.log(etime);


function renderCafe(doc) {
    let li = document.createElement('li');
    let names = document.createElement('span');
    let building = document.createElement('span');
    let time = document.createElement('span');
    let endtime = document.createElement('span');
    let modifytime = document.createElement('span');
    let createdby = document.createElement('span');
    let accept = document.createElement('span');
    let cross = document.createElement('div');
    let accepted = document.createElement('div2');

    var readableDate = doc.data().createdAt.toDate().toLocaleString();
    console.log(readableDate);

    var endDate = doc.data().endtime.toDate().toLocaleString();
    console.log(endDate);

    var modifyDate = doc.data().modifytime.toDate().toLocaleString();
    console.log(modifyDate);


    li.setAttribute('data-id', doc.id);
    names.textContent = ("住戶姓名：" + doc.data().names);
    building.textContent = ("住戶樓層：" + doc.data().ID);
    time.textContent = ("到貨時間:" + readableDate);
    endtime.textContent = ("到期時間:" + endDate);
    modifytime.textContent = ("領收時間:" + modifyDate);
    createdby.textContent = ("簽收管理員: " + doc.data().createdBy);
    accept.textContent = ("領收: " + doc.data().accept);
    cross.textContent = 'X';
    accepted.textContent = 'V';


    li.appendChild(names);
    li.appendChild(building);
    li.appendChild(time);
    li.appendChild(endtime);
    li.appendChild(createdby);
    li.appendChild(accept);
    if (doc.data().accept == "已領收") {
        li.appendChild(modifytime);
    };
    li.appendChild(cross);
    li.appendChild(accepted);

    package_List.appendChild(li);


    accepted.addEventListener('click', (e) => {
        if (doc.data().accept == "已領收") {
            swal("請勿重複領收");
        } else {
            swal({
                title: "包裹已領取了嗎?",
                text: "點確定後更新為已領取!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('mail pack').doc(id).update({
                        accept: "已領收",
                        modifytime: firebase.firestore.FieldValue.serverTimestamp(),
                    })
                    swal("您已成功更新資料", {
                        icon: "success",
                    });
                } else {
                    swal("包裹並未被領收!");
                }

            });

        }
    })

    // deleting data
    cross.addEventListener('click', (e) => {
        swal({
                title: "你確定嗎?",
                text: "點確定後資料將被刪除!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('mail pack').doc(id).delete();
                    swal("您已成功刪除資料", {
                        icon: "success",
                    });
                } else {
                    swal("資料完好如初!");
                }
            });

    });

}





function add() {
    location.href = "add_package.html";
}

addBtn.addEventListener('click', (e) => {
    add();
});

if (key === null) {
    an_db.collection('mail pack').where("accept", "==", "未領收").orderBy('createdAt', 'desc').onSnapshot(snapshot => {

        let changes = snapshot.docChanges();
        changes.forEach(change => {
            console.log(change.doc.data());
            if (change.type == 'added') {
                renderCafe(change.doc);
            } else if (change.type == 'removed') {
                let li = package_List.querySelector('[data-id=' + change.doc.id + ']');
                package_List.removeChild(li);
            }
        });
        sessionStorage.removeItem('key');
    });
} else if (choice == 1) {
    an_db.collection('mail pack').where("ID", "==", key).onSnapshot(snapshot => {
        let changes = snapshot.docChanges();
        changes.forEach(change => {
            console.log(change.doc.data());
            if (change.type == 'added') {
                renderCafe(change.doc);
            } else if (change.type == 'removed') {
                let li = package_List.querySelector('[data-id=' + change.doc.id + ']');
                package_List.removeChild(li);
            }
        });
        sessionStorage.removeItem('key');
    });
} else if (choice == 2) {
    var day = parseInt(key);
    var nextday = parseInt(etime);
    an_db.collection('mail pack').where("accept", "==", "未領收").where("endtimesecond", ">", day).where("endtimesecond", "<", nextday).onSnapshot(snapshot => {
        let changes = snapshot.docChanges();
        changes.forEach(change => {
            console.log(change.doc.data());
            if (change.type == 'added') {
                renderCafe(change.doc);
            } else if (change.type == 'removed') {
                let li = package_List.querySelector('[data-id=' + change.doc.id + ']');
                package_List.removeChild(li);
            }
        });
        sessionStorage.removeItem('key');
        sessionStorage.removeItem('etime');
    });
}

searchBtn.addEventListener('click', (e) => {
    var an_db = firebase.firestore();
    var ref = an_db.collection('mail pack').doc();
    ref.get().then(doc => {
        console.log(doc.data());
    });
    sessionStorage.setItem("key", searchtext.value);
    sessionStorage.setItem("choice", 1);
    location.href = "package.html";
});

endBtn.addEventListener('click', (e) => {
    var dt = new Date();
    var second = dt.getTime();
    var datetime = dt.setTime(second + 1000 * 60 * 60 * 24);
    var etime = dt.getTime(datetime);

    var an_db = firebase.firestore();
    var ref = an_db.collection('mail pack').doc();
    ref.get().then(doc => {
        console.log(doc.data());
    });
    sessionStorage.setItem("key", second);
    sessionStorage.setItem("choice", 2);
    sessionStorage.setItem("etime", etime);
    location.href = "package.html";
});