const addBtn = document.getElementById('addBtn');
const backBtn = document.getElementById('backBtn');
const database = firebase.firestore();
const usersCollection = database.collection('mail pack');
const doc_key = sessionStorage.getItem("key");
console.log(doc_key);
var docRef = database.collection("mail pack").doc(doc_key);
var names2;
var pack2;



addBtn.addEventListener('click', e => {
    let id = building.value + '-' + floor.value + '-' + door.value;
    console.log(id);
    if (building.value === null || building.value === '' || names.value === null || names.value === '' || floor.value === null || floor.value === '' || door.value === null || door.value === '' || pack.value === null || pack.value === '' || pack.value === 0) {
        swal("請輸入所有資料");
    } else {
        e.preventDefault();
        const ID = usersCollection.doc(id).set({
                names: names.value,
                pack: pack.value,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),

            })
            .then(() => {
                console.log('Data has been saved successfully !')
            })
        swal({
                title: "Good job!",
                text: "You clicked the button!",
                icon: "success",
                button: "Send successfully!",
            })
            .catch(error => {
                console.error(error)
            });
    }
});


backBtn.addEventListener('click', e => {
    location.href = "maildata.html";

});


docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        names2 = doc.data().names;
        console.log(names2);
        pack2 = doc.data().pack;
        var names = document.getElementById('names').value += names2;
        var pack = document.getElementById('pack').value += pack2;
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});