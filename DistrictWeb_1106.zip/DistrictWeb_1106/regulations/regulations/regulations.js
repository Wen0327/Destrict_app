const rule_List = document.querySelector('#rule_art');
const addBtn = document.getElementById('addBtn');
const form = document.querySelector('#rule_form');


//const an_db = firebase.firestore();

// create element & render cafe
function renderCafe(doc) {
    let li = document.createElement('li');
    let createdby = document.createElement('span');
    let time = document.createElement('span');
    let title = document.createElement('span');
    let content = document.createElement('span');
    let up = document.createElement('div');

    var readableDate = doc.data().createdAt.toDate().toLocaleString();
    console.log(readableDate);



    li.setAttribute('data-id', doc.id);
    createdby.textContent = ("修改管理員 : " + doc.data().createdBy);
    time.textContent = ("最後修改間:" + readableDate);
    title.textContent = ("標題:" + doc.data().title);
    content.textContent = ("規章內容: " + doc.data().content);
    up.textContent = 'V';

    li.appendChild(createdby);
    li.appendChild(time);
    li.appendChild(title);
    li.appendChild(content);
    li.appendChild(up);
    rule_List.appendChild(li);

    up.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        location.href = "modify_rule.html";
    })

}

function add02() {
    location.href = "../../index.html";
}

addBtn02.addEventListener('click', (e) => {
    add02();
});

an_db.collection('convent').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        console.log(change.doc.data());
        if (change.type == 'added') {
            renderCafe(change.doc);
        } else if (change.type == 'removed') {
            let li = rule_List.querySelector('[data-id=' + change.doc.id + ']');
            rule_List.removeChild(li);
        }
    });
});