const addBtn = document.getElementById('addBtn');
const backBtn = document.getElementById('backBtn');

const an_db = firebase.firestore();
const doc_key = sessionStorage.getItem("key");
console.log(doc_key);
var docRef = an_db.collection("convent").doc(doc_key);

var title2;
var content2;


const usersCollection = an_db.collection('convent');

addBtn.addEventListener('click', e => {
    if (title.value === null || title.value === '' || mo_ru_text.value === null || mo_ru_text.value === '') {
        swal("請輸入標題內容");
    } else {

        e.preventDefault();
        const ID = usersCollection.doc(doc_key).update({
                title: title.value,
                content: mo_ru_text.value,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                createdBy: AdminName,

            })
            .then(() => {
                console.log('Data has been saved successfully !')
            })
        swal({
                title: "Good job!",
                text: "You clicked the button!",
                icon: "success",
                button: "Send successfully!",
            })
            .catch(error => {
                console.error(error);
            });
    }
});

backBtn.addEventListener('click', e => {
    location.href = "rule.html";
});

docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        title2 = doc.data().title;
        console.log(title2);
        content2 = doc.data().content;
        console.log(content2);

        var title = document.getElementById('title').value += title2;
        var mo_ru_text = document.getElementById('mo_ru_text').value += content2;

    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});