
const timely = document.querySelector('#timely');
const reservation = document.querySelector('#reservation');
const calledcar = document.querySelector('#calledcar');


var 及時叫車 = document.getElementById('taxitimely');
var 預約叫車 = document.getElementById('taxireservation');
var 已叫車資料 = document.getElementById('taxicalledcar');
var link_top = document.getElementById('link-top');

及時叫車.style.color = '	#127436';

function Timely(doc) {
    let li = document.createElement('li');
    let recID = document.createElement('span');
    let type = document.createElement('span');
    let date = document.createElement('span');
    let time = document.createElement('span');
    let mode = document.createElement('span');
    let 叫車 = document.createElement("button");
    let 刪除 = document.createElement("button");

    li.setAttribute('data-id', doc.id);
    recID.textContent = (doc.data().recID);
    type.textContent = (doc.data().type);
    date.textContent = (doc.data().date);
    time.textContent = (doc.data().time);
    mode.textContent = (doc.data().mode);
    叫車.textContent = '叫車';
    刪除.textContent = '刪除';

    li.appendChild(recID);
    li.appendChild(type);
    li.appendChild(date);
    li.appendChild(time);
    li.appendChild(mode);
    li.appendChild(叫車);
    li.appendChild(刪除);
    timely.appendChild(li);

    叫車.addEventListener('click', (e) => {
        if (doc.data().mode == "已叫車") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要叫車了嗎?",
                text: "點確定後更新為已叫車!",
                icon: "warning",
                buttons: true,
                dangerMode: true,

            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('taxi').doc(id).update({
                        mode: "已叫車",
                        叫車時間: firebase.firestore.FieldValue.serverTimestamp(),
                    })

                } else {
                    swal("取消叫車!");
                }
                setTimeout(function() { window.location.reload(); }, 1500);
            });
        }

    })
    刪除.addEventListener('click', (e) => {
        swal({
                title: "是否要刪除?",
                text: "確認後將刪除資料!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('taxi').doc(id).delete();
                    swal("成功刪除!", {
                        icon: "success",
                    });
                } else {
                    swal("取消刪除!");
                }
                setTimeout(function() { window.location.reload(); }, 1500);
            });

    });
    及時叫車.addEventListener('click', (e) => {

        let id = e.target.parentElement.getAttribute('data-id');


        及時叫車.style.color = '	#127436';
        預約叫車.style.color = '	#404040';
        已叫車資料.style.color = '	#404040';
        taxiprogress.style.marginLeft = '70px'

        $('#reservation').empty();
        $('#calledcar').empty();
        setTimeout(function() { window.location.reload(); }, 200);

    })
}

function Reservation(doc) {
    let li = document.createElement('li');
    let recID = document.createElement('span');
    let type = document.createElement('span');
    let reservationTime = document.createElement('span');
    let date = document.createElement('span');
    let mode = document.createElement('span');
    let 叫車 = document.createElement("button");
    let 刪除 = document.createElement("button");

    li.setAttribute('data-id', doc.id);
    recID.textContent = (doc.data().recID);
    type.textContent = (doc.data().type);
    reservationTime.textContent = (doc.data().reservationTime);
    date.textContent = (doc.data().date);
    mode.textContent = (doc.data().mode);
    叫車.textContent = '叫車';
    刪除.textContent = '刪除';

    li.appendChild(recID);
    li.appendChild(type);
    li.appendChild(date);
    li.appendChild(reservationTime);
    li.appendChild(mode);
    li.appendChild(叫車);
    li.appendChild(刪除);

    叫車.addEventListener('click', (e) => {
        if (doc.data().mode == "已叫車") {
            sawl("請勿重複點選");
        } else {
            swal({
                title: "確定要叫車了嗎?",
                text: "點確定後更新為已叫車!",
                icon: "warning",
                buttons: true,
                dangerMode: true,

            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('taxi').doc(id).update({
                        mode: "已叫車",
                    })

                } else {
                    swal("取消叫車!");
                }
                setTimeout(function() { window.location.reload(); }, 1500);
            });
        }

    })

    刪除.addEventListener('click', (e) => {
        swal({
                title: "是否要刪除?",
                text: "確認後將刪除資料!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('taxi').doc(id).delete();
                    swal("成功刪除!", {
                        icon: "success",
                    });
                } else {
                    swal("取消刪除!");
                }
                setTimeout(function() { window.location.reload(); }, 1500);
            });

    });

    預約叫車.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');

        taxiprogress.style.marginLeft = '250px'
        已叫車資料.style.color = '	#404040';
        及時叫車.style.color = '	#404040';
        預約叫車.style.color = '	#127436';
        reservation.appendChild(li);
        $('#timely').empty();
        $('#calledcar').empty();

    })

}

function Calledcar(doc) {
    let li = document.createElement('li');
    let recID = document.createElement('span');
    let type = document.createElement('span');
    let date = document.createElement('span');
    let time = document.createElement('span');
    let mode = document.createElement('span');
    let 叫車 = document.createElement("button");
    let 刪除 = document.createElement("button");

    li.setAttribute('data-id', doc.id);
    recID.textContent = (doc.data().recID);
    type.textContent = (doc.data().type);
    date.textContent = (doc.data().date);
    time.textContent = (doc.data().time);
    mode.textContent = (doc.data().mode);
    叫車.textContent = '叫車';
    刪除.textContent = '刪除';

    li.appendChild(recID);
    li.appendChild(type);
    li.appendChild(date);
    li.appendChild(time);
    li.appendChild(mode);
    li.appendChild(叫車);
    li.appendChild(刪除);


    叫車.addEventListener('click', (e) => {
        if (doc.data().mode == "已叫車") {
            swal("請勿重複點選");
        } else {
            swal({
                title: "確定要叫車了嗎?",
                text: "點確定後更新為已叫車!",
                icon: "warning",
                buttons: true,
                dangerMode: true,

            }).then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('taxi').doc(id).update({
                        mode: "已叫車",
                    })

                } else {
                    swal("取消叫車!");
                }
                setTimeout(function() { window.location.reload(); }, 1500);
            });
        }

    })
    刪除.addEventListener('click', (e) => {
        swal({
                title: "是否要刪除?",
                text: "確認後將刪除資料!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('taxi').doc(id).delete();
                    swal("成功刪除!", {
                        icon: "success",
                    });
                } else {
                    swal("取消刪除!");
                }
                setTimeout(function() { window.location.reload(); }, 1500);
            });

    });
    已叫車資料.addEventListener('click', (e) => {

        let id = e.target.parentElement.getAttribute('data-id');

        及時叫車.style.color = '	#404040';
        已叫車資料.style.color = '	#127436';
        預約叫車.style.color = '	#404040';
        taxiprogress.style.marginLeft = '455px'
        calledcar.appendChild(li);
        $('#reservation').empty();
        $('#timely').empty();


    })
}

an_db.collection('taxi').where('reservation', '==', '今日').where('mode', '==', '未叫車').orderBy('createdAt', 'desc').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if (change.type == 'added') {
            Timely(change.doc);
        } else if (change.type == 'removed') {
            let li = timely.querySelector('[data-id=' + change.doc.id + ']');
            timely.removeChild(li);
        }

    });
});

an_db.collection('taxi').where('reservation', '==', '預約').orderBy('createdAt', 'desc').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if (change.type == 'added') {
            Reservation(change.doc);
        } else if (change.type == 'removed') {
            let li = reservation.querySelector('[data-id=' + change.doc.id + ']');
            reservation.removeChild(li);
        }

    })
})
an_db.collection('taxi').where('mode', '==', '已叫車').orderBy('createdAt', 'desc').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        if (change.type == 'added') {
            Calledcar(change.doc);
        } else if (change.type == 'removed') {
            let li = calledcar.querySelector('[data-id=' + change.doc.id + ']');
            calledcar.removeChild(li);
        }

    })
})