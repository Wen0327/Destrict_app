var labelsArray = [];
var dataArray = [];

a87();

const MONTHS = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
];
const CHART_COLORS = {
    red: 'rgb(255, 99, 132)',
    orange: 'rgb(255, 159, 64)',
    yellow: 'rgb(255, 205, 86)',
    green: 'rgb(75, 192, 192)',
    blue: 'rgb(54, 162, 235)',
    purple: 'rgb(153, 102, 255)',
    grey: 'rgb(201, 203, 207)'
};

function months(config) {
    var cfg = config || {};
    var count = cfg.count || 12;
    var section = cfg.section;
    var values = [];
    var i, value;

    for (i = 0; i < count; ++i) {
        value = MONTHS[Math.ceil(i) % 12];
        values.push(value.substring(0, section));
    }

    return values;
}


async function a87() {
    await db.collection("equipmentReport").orderBy('createdAt', 'desc').get().then((snapshot) => {
        snapshot.docs.forEach(doc => {

            var 結束時間_Date = doc.data().createdAt.toDate().toLocaleDateString();
            labelsArray.push(doc.data().申報項目 + 結束時間_Date);

            var a = doc.data().已完成時間.seconds;
            var b = doc.data().已接收時間.seconds;
            var time = a - b;

            console.log(time);

            dataArray.push(time);


            console.log(doc.id, " => ", doc.data());
        });
    });

    const labels = months({ count: 12 });
    var ctx = document.getElementById("myChart");
    Chart.defaults.font.size = 13;
    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                    label: '水管',
                    data: [8.1, 8.6, 0.2, 2.3, 1.8, 4.3, 2, 8.9, 4.9, 5.4, 9.2, 2.7],
                    borderColor: CHART_COLORS.red,
                    backgroundColor: CHART_COLORS.red,
                },
                {
                    label: '公共設備',
                    data: [5.2, 3.1, 6.5, 3.2, 1.1, 8.2, 5.1, 9.4, 0.7, 2.7, 0.6, 4.8],
                    hidden: true,
                    borderColor: CHART_COLORS.blue,
                    backgroundColor: CHART_COLORS.blue,
                },
                {
                    label: '電梯',
                    data: [2.2, 7.5, 8.6, 1.5, 5.9, 8.6, 8.1, 3, 7.5, 9.2, 2.5, 1.2],
                    hidden: true,
                    borderColor: CHART_COLORS.yellow,
                    backgroundColor: CHART_COLORS.yellow,
                },
                {
                    label: '地面',
                    data: [6.2, 6.4, 0.7, 6.9, 5.6, 1, 8.4, 9.6, 0.2, 0.3, 6.3, 6],
                    hidden: true,
                    borderColor: CHART_COLORS.green,
                    backgroundColor: CHART_COLORS.green,
                }

            ]
        },


        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',

                },
                title: {
                    display: true,
                    text: '報修回饋圖表',
                    font: { size: 30 }
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true
                    }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Day'
                    },

                }
            }
        }
    });
}