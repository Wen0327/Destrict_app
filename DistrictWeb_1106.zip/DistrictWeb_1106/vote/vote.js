const vote_title = document.getElementById('vote_title');
const start_time = document.getElementById('start_time');
const end_time = document.getElementById('end_time');
const vote_content = document.getElementById('vote_content');
const vote_type = document.getElementById('vote_type');
const vote_description = document.getElementById('vote_description');
const A = document.getElementById('A');
const B = document.getElementById('B');
const C = document.getElementById('C');
const D = document.getElementById('D');

const A2 = Number("0");
const B2 = Number("0");
const C2 = Number("0");
const D2 = Number("0");

const addBtn = document.getElementById('addBtn');
const backBtn = document.getElementById('backBtn');


const usersCollection = an_db.collection('vote');

console.log(AdminId);
var docRef = an_db.collection("admin").doc(AdminId);



docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        AdminName = doc.data().name;
        console.log(AdminName);
        addBtn.addEventListener('click', e => {
            if (vote_title.value === null || vote_title.value === '' || vote_content.value === null || vote_content.value === '' || end_time.value === null || end_time.value === '' ||
                start_time.value === null || start_time.value === '' || A.value === null || A.value === '' || B.value === null || B.value === '') {
                swal("請輸入內容");

            } else {

                e.preventDefault();

                const ID = usersCollection.doc().set({

                        createdBy: AdminName,
                        vote_title: vote_title.value,
                        vote_type: vote_type.value,
                        start_time: start_time.value,
                        end_time: end_time.value,
                        vote_content: vote_content.value,
                        vote_description: vote_description.value,
                        選項1: A2,
                        選項2: B2,
                        選項3: C2,
                        選項4: D2,
                        result: "投票未結束",
                        A: A.value,
                        B: B.value,
                        C: C.value,
                        D: D.value,
                        createdAt: firebase.firestore.FieldValue.serverTimestamp(),

                    })
                    .then(() => {
                        console.log('Data has been saved successfully !')
                    })
                swal({
                        title: "Good job!",
                        text: "You clicked the button!",
                        icon: "success",
                        button: "Send successfully!",
                    })
                    .catch(error => {
                        console.error(error)
                    });
            }
        });
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});


function add() {
    location.href = "vote_v2.html";
}

backBtn.addEventListener('click', e => {
    add();
});