const vote_List = document.querySelector('#V_art');
const addBtn = document.getElementById('addBtn');
const Btn = document.getElementById('Btn');
const addBtn02 = document.getElementById('addBtn02');
const addBtnend = document.getElementById('addBtnend');
const addBtnend02 = document.getElementById('addBtnend02');
const vote_form = document.querySelector('#form');



const name1 = sessionStorage.getItem('name1');
console.log(name1);
const type = sessionStorage.getItem('type');
console.log(type);
const today = sessionStorage.getItem('today');
console.log(today);

console.log(AdminId);

// create element & render cafe
function renderCafe(doc) {
    let li = document.createElement('li');
    let createdby = document.createElement('span');
    let vote_title = document.createElement('span');
    let vote_type = document.createElement('span');
    let start_time = document.createElement('span');
    let end_time = document.createElement('span');
    let time = document.createElement('span');
    let 選項1 = document.createElement('span');
    let 選項2 = document.createElement('span');
    let 選項3 = document.createElement('span');
    let 選項4 = document.createElement('span');
    let result = document.createElement('span');
    let vote_content = document.createElement('span');
    let vote_description = document.createElement('span');
    let cross = document.createElement('div');
    let up = document.createElement('div2');
    let end = document.createElement('div3');

    var readableDate = doc.data().createdAt.toDate().toLocaleDateString();
    console.log(readableDate);
    li.setAttribute('data-id', doc.id);
    createdby.textContent = ("創建管理員: " + doc.data().createdBy);
    vote_title.textContent = ("標題:" + doc.data().vote_title);
    vote_type.textContent = ("投票類型:" + doc.data().vote_type);
    start_time.textContent = ("開始時間:" + doc.data().start_time);
    end_time.textContent = ("結束時間:" + doc.data().end_time);
    選項1.textContent = (doc.data().A + "的投票人數: " + doc.data().選項1);
    選項2.textContent = (doc.data().B + "的投票人數: " + doc.data().選項2);
    選項3.textContent = (doc.data().C + "的投票人數: " + doc.data().選項3);
    選項4.textContent = (doc.data().D + "的投票人數: " + doc.data().選項4);
    result.textContent = ("投票結果:" + doc.data().result);
    time.textContent = readableDate;
    vote_content.textContent = ("投票描述: " + doc.data().vote_content);
    vote_description.textContent = ("投票內容: " + doc.data().vote_description);
    cross.textContent = '刪除';
    up.textContent = '修改';
    end.textContent = '結束';

    li.appendChild(createdby);
    li.appendChild(vote_title);
    li.appendChild(vote_type);
    li.appendChild(start_time);
    li.appendChild(end_time);
    li.appendChild(選項1);
    li.appendChild(選項2);
    li.appendChild(選項3);
    li.appendChild(選項4);
    li.appendChild(result);
    li.appendChild(time);
    li.appendChild(vote_content);
    li.appendChild(vote_description);
    li.appendChild(up);
    li.appendChild(cross);
    li.appendChild(end);
    vote_List.appendChild(li);


    up.addEventListener('click', (e) => {
        let id = e.target.parentElement.getAttribute('data-id');
        sessionStorage.setItem("key", id);
        location.href = "vote_modify.php";
    });

    end.addEventListener('click', (e) => {
        swal({
                title: "Are you sure?",
                text: "你要結束投票嗎",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willend) => {
                if (willend) {

                    let id = e.target.parentElement.getAttribute('data-id');
                    const doc_key = id;
                    console.log(doc_key);

                    an_db.collection('vote').doc(doc_key).get().then((doc) => {
                        if (doc.data().選項1 > doc.data().選項2 && doc.data().選項1 > doc.data().選項3 && doc.data().選項1 > doc.data().選項4) {
                            var max = doc.data().A + "最高";
                        } else if (doc.data().選項2 > doc.data().選項3 && doc.data().選項2 > doc.data().選項4) {
                            var max = doc.data().B + "最高";
                        } else if (doc.data().選項3 > doc.data().選項4) {
                            var max = doc.data().C + "最高";
                        } else if (doc.data().選項4 > 0) {
                            var max = doc.data().D + "最高";
                        } else {
                            var max = "平票";
                        }
                        const ID = an_db.collection('vote').doc(doc_key).update(

                            {
                                result: max,
                            });

                    });

                    swal("投票結束了!", {
                        icon: "success",

                    }).then(function() {
                        window.location.href = "vote_v2.html"
                    })


                } else {
                    swal("你取消了");
                }

            });


    });
    // deleting data
    cross.addEventListener('click', (e) => {
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this imaginary file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    e.stopPropagation();
                    let id = e.target.parentElement.getAttribute('data-id');
                    an_db.collection('vote').doc(id).delete();
                    swal("Poof! Your imaginary file has been deleted!", {
                        icon: "success",
                    });
                } else {
                    swal("Your imaginary file is safe!");
                }
            });

    });










}


if (name1 === null) {
    an_db.collection('vote').where('result', '==', '投票未結束').orderBy('createdAt', 'desc').onSnapshot(snapshot => {
        let changes = snapshot.docChanges();
        changes.forEach(change => {
            console.log(change.doc.data());
            if (change.type == 'added') {

                renderCafe(change.doc);


            } else if (change.type == 'removed') {
                let li = vote_List.querySelector('[data-id=' + change.doc.id + ']');
                vote_List.removeChild(li);
            }
        });
        sessionStorage.removeItem('name1');
    });

} else if (type == 1) {
    var day = today;


    an_db.collection('vote').where('end_time', '<', day).onSnapshot(snapshot => {

        let changes = snapshot.docChanges();
        changes.forEach(change => {


            console.log(change.doc.data());
            if (change.type == 'added') {
                renderCafe(change.doc);
            } else if (change.type == 'removed') {
                let li = vote_List.querySelector('[data-id=' + change.doc.id + ']');
                vote_List.removeChild(li);
            }
        });
        sessionStorage.removeItem('name1');
        sessionStorage.removeItem('type');
        sessionStorage.removeItem('today');


    });




} else if (type == 2) {
    an_db.collection('vote').where('result', '!=', '投票未結束').onSnapshot(snapshot => {

        let changes = snapshot.docChanges();
        changes.forEach(change => {


            console.log(change.doc.data());
            if (change.type == 'added') {
                renderCafe(change.doc);
            } else if (change.type == 'removed') {
                let li = vote_List.querySelector('[data-id=' + change.doc.id + ']');
                vote_List.removeChild(li);
            }
        });
        sessionStorage.removeItem('name1');
        sessionStorage.removeItem('type');



    });
}




function add() {
    location.href = "add_vote_v2.html";
}



addBtn.addEventListener('click', (e) => {
    add();
});


Btn.addEventListener('click', (e) => {
    sessionStorage.removeItem('name1');
    sessionStorage.removeItem('type');
    location.href = "vote_v2.html";

});

/*
function add02() {
    location.href = "../index.html";
}



addBtn02.addEventListener('click', (e) => {
    add02();
});
*/

addBtnend.addEventListener('click', (e) => {
    var end = "end";
    var today = new Date().toISOString().slice(0, 10);
    var an_db = firebase.firestore();
    var ref = an_db.collection('vote').doc();
    ref.get().then(doc => {
        console.log(doc.data());
    });
    sessionStorage.setItem("name1", end);
    sessionStorage.setItem("type", 1);
    sessionStorage.setItem("today", today);
    location.href = "vote_v2.html";
});
addBtnend02.addEventListener('click', (e) => {
    var end02 = "end02";
    var an_db = firebase.firestore();
    var ref = an_db.collection('vote').doc();
    ref.get().then(doc => {
        console.log(doc.data());
    });
    sessionStorage.setItem("name1", end02);
    sessionStorage.setItem("type", 2);
    location.href = "vote_v2.html";
});