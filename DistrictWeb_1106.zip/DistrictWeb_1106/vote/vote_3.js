const addBtn = document.getElementById('addBtn');
const backBtn = document.getElementById('backBtn');
const database = firebase.firestore();

const doc_key = sessionStorage.getItem("key");
console.log(doc_key);
var docRef = database.collection("vote").doc(doc_key);

var vote_title2;
var start_time2;
var end_time2;

var A;
var B;
var C;
var D;

var vote_content2;
var vote_description2;
var vote_option2;


const usersCollection = database.collection('vote');

addBtn.addEventListener('click', e => {
    if (vote_title.value === null || vote_title.value === '' || vote_content.value === null || vote_content.value === '' || end_time.value === null || end_time.value === '' || start_time.value === null || start_time.value === '') {
        swal("請輸入標題內容");
    } else {

        e.preventDefault();
        const ID = usersCollection.doc(doc_key).update({
                vote_title: vote_title.value,
                start_time: start_time.value,
                end_time: end_time.value,
                A: A.value,
                B: B.value,
                C: C.value,
                D: D.value,
                vote_content: vote_content.value,
                vote_description: vote_description.value,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),

            })
            .then(() => {
                console.log('Data has been saved successfully !')
            })
        swal({
                title: "Good job!",
                text: "You clicked the button!",
                icon: "success",
                button: "Send successfully!",
            })
            .catch(error => {
                console.error(error)
            });
    }
});

backBtn.addEventListener('click', e => {
    location.href = "vote_main.php";
});

docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        vote_title2 = doc.data().vote_title;
        console.log(vote_title2);
        start_time2 = doc.data().start_time;
        console.log(start_time2);
        end_time2 = doc.data().end_time;
        console.log(end_time2);
        A2 = doc.data().A;
        console.log(A2);
        B2 = doc.data().B;
        console.log(B2);
        C2 = doc.data().C;
        console.log(C2);
        D2 = doc.data().D;
        console.log(D2);
        vote_content2 = doc.data().vote_content;
        console.log(vote_content2);
        vote_description2 = doc.data().vote_description;
        console.log(vote_description2);
        var title = document.getElementById('vote_title').value += vote_title2;
        var title = document.getElementById('start_time').value += start_time2;
        var title = document.getElementById('end_time').value += end_time2;
        var title = document.getElementById('A').value += A2;
        var title = document.getElementById('B').value += B2;
        var title = document.getElementById('C').value += C2;
        var title = document.getElementById('D').value += D2;
        var title = document.getElementById('vote_content').value += vote_content2;
        var content = document.getElementById('vote_description').value += vote_description2;


    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});